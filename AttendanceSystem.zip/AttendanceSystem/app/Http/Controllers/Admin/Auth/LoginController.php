<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\Models\User;

class LoginController extends Controller
{
    public function showLoginForm()
    {
        return view('admin.auth.login');
    }
    public function Login(Request $request)
{
    // Validate the input
    $validator = Validator::make($request->all(), [
        'email' => 'required|email',
        'password' => 'required|min:8',
    ]);

    // Check if the validation fails
    if ($validator->fails()) {
        return redirect()->back()
            ->withErrors($validator)
            ->withInput(); // Redirect back with errors and old input
    }

    // Check if the user exists and their account status
    $user = User::where('email', $request->email)->first();

    // Check if user exists and if their account is disabled
    if ($user && $user->status == 0) {
        return redirect()->back()
            ->with('message', 'Your account is disabled.')
            ->with('alert', 'error');
    }else if ($user && $user->status == 2){
        return redirect()->back()
        ->with('message', 'Your account is deleted.')
        ->with('alert', 'error');
    }
    // Check for valid credentials and attempt login
    $remember_me = ($request->remember_me) ? true : false;
    if (!auth()->guard('web')->attempt(['email' => $request->email, 'password' => $request->password], $remember_me)) {
        return redirect()->back()
            ->with('message', 'Invalid email or password')
            ->with('alert', 'error');
    }

    // If login is successful, redirect to admin dashboard
    return redirect()->route('admin.dashboard')
        ->with('message', 'Login Successfully!')
        ->with('alert', 'success');
}
}