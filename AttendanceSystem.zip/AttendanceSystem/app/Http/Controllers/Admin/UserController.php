<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\BusinessUnit;
use Spatie\Permission\Models\Role;
use DB;
use Hash;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Validator;


class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    // public function __construct()
    // {
    //     $this->middleware('permission:users-view|users-create|users-edit|users-delete', ['only' => ['index', 'store']]);
    //     $this->middleware('permission:users-create', ['only' => ['create', 'store']]);
    //     $this->middleware('permission:users-edit', ['only' => ['edit', 'update']]);
    //     $this->middleware('permission:users-delete', ['only' => ['destroy']]);
    // }
    public function index()
    {
        $data = User::orderBy('id', 'desc')->where('type', '!=', 'super_admin')->where('status', '!=', 2)->get();
        return view('admin.users.index',compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $roles = Role::where('guard_name', 'web')->pluck('name', 'name')->all();
        return view('admin.users.create',compact('roles'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed|min:8', // 'password_confirmation' is automatically checked
            'roles' => 'required'
        ]);

        // Check if the validation fails
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput(); // Redirect back with errors and old input
        }

        // Validation passed, create the user
        $data = [
            'name' => $request->name,
            'email' => $request->email,
            'type' => 'sub_admin',
            'password' => Hash::make($request->password),
            'status' => $request->status,
        ];
        $user = User::create($data);
        $user->assignRole($request->input('roles'));
        if ($user) {
            return redirect()->route('admin.users.index')
                ->with('message', 'User created successfully!')
                ->with('alert', 'success');
        } else {
            return redirect()->back()
                ->with('message', 'Something went wrong, please try again.')
                ->with('alert', 'error');
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $user = User::find($id);
        $ownerships = User::where('id', '!=', $id)->select('id', 'firstname', 'email')->where('status', '!=', 3)->get();
        $roles = Role::where('guard_name', 'web')->pluck('name','name')->all();
        $units = BusinessUnit::all();
        $userRole = $user->roles->pluck('name','name')->all();
        return view('admin.users.view',compact('user','roles','userRole','units','ownerships'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $user = User::find($id);
        $roles = Role::where('guard_name', 'web')->pluck('name','name')->all();
        $userRole = $user->roles->pluck('name','name')->all();

        return view('admin.users.edit',compact('user','roles','userRole'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,'.$id,
            'roles' => 'required'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput(); // Redirect back with errors and old input
        }

        $input = $request->all();
        $user = User::find($id);
        $user->update($input);
        DB::table('model_has_roles')->where('model_id',$id)->delete();
        $user->assignRole($request->input('roles'));
        return redirect()->route('admin.users.index')
        ->with('message', 'User updated successfully!')
        ->with('alert', 'success');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
{
    
    // Proceed to delete the user if no associations exist
    $user = User::find($id);
    $user->status = '3';
    $user->save();

    return redirect()->route('admin.users.index')
        ->with('message', 'User deleted successfully.')
        ->with('alert', 'success');
}

}
