<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\BusinessUnit;
use Illuminate\Support\Facades\Validator;

class BusinessUnitController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = BusinessUnit::where('status', '!=', 2)->orderBy('id', 'desc')->get();
        $timezones = config('timezones');
        return view('admin.businessUnit.index', compact('data', 'timezones'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $timezones = config('timezones');
        return view('admin.businessUnit.create', compact('timezones'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'timezone' => 'required|string|max:255',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'radius_meters' => 'nullable|integer|min:1|max:10000',
            'status' => 'required|in:0,1'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $data = [
                'name' => $request->name,
                'timezone' => $request->timezone,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'radius_meters' => $request->radius_meters ?? 100,
                'status' => $request->status,
            ];
            
            $businessUnit = BusinessUnit::create($data);
            
            if ($businessUnit) {
                return redirect()->route('admin.business-unit.index')
                    ->with('message', 'Business Unit created successfully!')
                    ->with('alert', 'success');
            } else {
                return redirect()->back()
                    ->with('message', 'Something went wrong, please try again.')
                    ->with('alert', 'error');
            }
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('message', 'Something went wrong: ' . $e->getMessage())
                ->with('alert', 'error')
                ->withInput();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $businessUnit = BusinessUnit::findOrFail($id);
        $timezones = config('timezones');
        return view('admin.businessUnit.view', compact('businessUnit', 'timezones'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $businessUnit = BusinessUnit::findOrFail($id);
        $timezones = config('timezones');
        return view('admin.businessUnit.edit', compact('businessUnit', 'timezones'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $businessUnit = BusinessUnit::findOrFail($id);
        
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'timezone' => 'required|string|max:255',
            'latitude' => 'nullable|numeric|between:-90,90',
            'longitude' => 'nullable|numeric|between:-180,180',
            'radius_meters' => 'nullable|integer|min:1|max:10000',
            'status' => 'required|in:0,1'
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        try {
            $data = [
                'name' => $request->name,
                'timezone' => $request->timezone,
                'latitude' => $request->latitude,
                'longitude' => $request->longitude,
                'radius_meters' => $request->radius_meters ?? 100,
                'status' => $request->status,
            ];
            
            $businessUnit->update($data);

            return redirect()->route('admin.business-unit.index')
                ->with('message', 'Business Unit updated successfully!')
                ->with('alert', 'success');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('message', 'Something went wrong: ' . $e->getMessage())
                ->with('alert', 'error')
                ->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            $businessUnit = BusinessUnit::findOrFail($id);
            
            // Check if business unit has employees
            if ($businessUnit->employees()->count() > 0) {
                return redirect()->back()
                    ->with('message', 'Cannot delete business unit. It has associated employees.')
                    ->with('alert', 'error');
            }
            
            // Soft delete by updating status
            $businessUnit->status = 2;
            $businessUnit->save();

            return redirect()->route('admin.business-unit.index')
                ->with('message', 'Business Unit deleted successfully.')
                ->with('alert', 'success');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('message', 'Something went wrong: ' . $e->getMessage())
                ->with('alert', 'error');
        }
    }
}
