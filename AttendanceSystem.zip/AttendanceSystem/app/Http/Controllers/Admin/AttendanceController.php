<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Attendance;
use App\Models\User;
use App\Models\EmployeeDetail;
use App\Models\Schedule;
use App\Models\BusinessUnit;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class AttendanceController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Attendance::with(['user', 'employeeDetail.businessUnit', 'employeeDetail.schedule']);
        
        // Filter by date range
        if ($request->filled('start_date')) {
            $query->where('attendance_date', '>=', $request->start_date);
        }
        if ($request->filled('end_date')) {
            $query->where('attendance_date', '<=', $request->end_date);
        }

        // Filter by employee
        if ($request->filled('employee_id')) {
            $query->where('user_id', $request->employee_id);
        }

        // Filter by business unit
        if ($request->filled('business_unit_id')) {
            $query->whereHas('employeeDetail', function($q) use ($request) {
                $q->where('business_unit_id', $request->business_unit_id);
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Default to current month if no date range provided
        if (!$request->filled('start_date') && !$request->filled('end_date')) {
            $query->whereMonth('attendance_date', Carbon::now()->month)
                  ->whereYear('attendance_date', Carbon::now()->year);
        }

        $attendances = $query->orderBy('attendance_date', 'desc')
                           ->orderBy('check_in_time', 'desc')
                           ->paginate(20);

        // Get filter data
        $employees = User::where('type', 'employee')
                        ->where('status', 1)
                        ->with('employeeDetail')
                        ->get();

        $businessUnits = BusinessUnit::where('status', 1)->get();

        // Get statistics
        $stats = $this->getAttendanceStats($request);

        return view('admin.attendances.index', compact(
            'attendances', 
            'employees', 
            'businessUnits', 
            'stats'
        ));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $employees = User::where('type', 'employee')
                        ->where('status', 1)
                        ->with('employeeDetail.businessUnit', 'employeeDetail.schedule')
                        ->get();

        return view('admin.attendances.create', compact('employees'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'user_id' => 'required|exists:users,id',
            'attendance_date' => 'required|date',
            'check_in_time' => 'nullable|date_format:H:i',
            'check_out_time' => 'nullable|date_format:H:i|after:check_in_time',
            'status' => 'required|in:present,absent,late,half_day,overtime',
            'notes' => 'nullable|string|max:500',
        ]);

        // Check if attendance already exists for this user and date
        $existingAttendance = Attendance::where('user_id', $request->user_id)
                                      ->where('attendance_date', $request->attendance_date)
                                      ->first();

        if ($existingAttendance) {
            return redirect()->back()
                ->with('message', 'Attendance record already exists for this employee on this date.')
                ->with('alert', 'error');
        }

        // Get employee details with business unit
        $employee = EmployeeDetail::where('user_id', $request->user_id)
                                 ->with('businessUnit', 'schedule')
                                 ->first();
        if (!$employee) {
            return redirect()->back()
                ->with('message', 'Employee details not found.')
                ->with('alert', 'error');
        }

        // Get schedule times
        $scheduledCheckIn = null;
        $scheduledCheckOut = null;
        if ($employee->schedule) {
            $scheduledCheckIn = $employee->schedule->time_in;
            $scheduledCheckOut = $employee->schedule->time_out;
        }

        // Get business unit timezone
        $timezone = $employee->businessUnit->timezone ?? 'UTC';
        
        // Calculate late minutes and early departure using timezone
        $lateMinutes = 0;
        $earlyDepartureMinutes = 0;
        $totalWorkingMinutes = 0;

        if ($request->check_in_time && $scheduledCheckIn) {
            $checkIn = Carbon::parse($request->attendance_date . ' ' . $request->check_in_time, $timezone);
            $scheduledIn = Carbon::parse($request->attendance_date . ' ' . $scheduledCheckIn, $timezone);
            if ($checkIn->gt($scheduledIn)) {
                $lateMinutes = abs($checkIn->diffInMinutes($scheduledIn, false));
            }
        }
        
        if ($request->check_out_time && $scheduledCheckOut) {
            $checkOut = Carbon::parse($request->attendance_date . ' ' . $request->check_out_time, $timezone);
            $scheduledOut = Carbon::parse($request->attendance_date . ' ' . $scheduledCheckOut, $timezone);
            if ($checkOut->lt($scheduledOut)) {
                $earlyDepartureMinutes = abs($scheduledOut->diffInMinutes($checkOut, false));
            }
        }
        

        if ($request->check_in_time && $request->check_out_time) {
            $checkIn = Carbon::parse($request->attendance_date . ' ' . $request->check_in_time, $timezone);
            $checkOut = Carbon::parse($request->attendance_date . ' ' . $request->check_out_time, $timezone);
            
            // Ensure check-out is after check-in
            if ($checkOut->gt($checkIn)) {
                $totalWorkingMinutes = $checkIn->diffInMinutes($checkOut);
            } else {
                $totalWorkingMinutes = 0; // Invalid time range
            }
        }

        $attendance = Attendance::create([
            'user_id' => $request->user_id,
            'employee_detail_id' => $employee->id,
            'attendance_date' => $request->attendance_date,
            'check_in_time' => $request->check_in_time,
            'check_out_time' => $request->check_out_time,
            'scheduled_check_in' => $scheduledCheckIn,
            'scheduled_check_out' => $scheduledCheckOut,
            'late_minutes' => $lateMinutes,
            'early_departure_minutes' => $earlyDepartureMinutes,
            'total_working_minutes' => $totalWorkingMinutes,
            'status' => $request->status,
            'notes' => $request->notes,
            'check_in_location' => $request->check_in_location,
            'check_out_location' => $request->check_out_location,
            'device_id' => $request->device_id,
        ]);

        return redirect()->route('admin.attendances.index')
            ->with('message', 'Attendance record created successfully!')
            ->with('alert', 'success');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $attendance = Attendance::with(['user', 'employeeDetail.businessUnit', 'employeeDetail.schedule'])
                              ->findOrFail($id);

        return view('admin.attendances.view', compact('attendance'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $attendance = Attendance::with(['user', 'employeeDetail.businessUnit', 'employeeDetail.schedule'])
                              ->findOrFail($id);

        $employees = User::where('type', 'employee')
                        ->where('status', 1)
                        ->with('employeeDetail.businessUnit', 'employeeDetail.schedule')
                        ->get();

        return view('admin.attendances.edit', compact('attendance', 'employees'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $attendance = Attendance::findOrFail($id);

        $request->validate([
            'user_id' => 'required|exists:users,id',
            'attendance_date' => 'required|date',
            'check_in_time' => 'nullable|date_format:H:i',
            'check_out_time' => 'nullable|date_format:H:i|after:check_in_time',
            'status' => 'required|in:present,absent,late,half_day,overtime',
            'notes' => 'nullable|string|max:500',
        ]);

        // Check if attendance already exists for this user and date (excluding current record)
        $existingAttendance = Attendance::where('user_id', $request->user_id)
                                      ->where('attendance_date', $request->attendance_date)
                                      ->where('id', '!=', $id)
                                      ->first();

        if ($existingAttendance) {
            return redirect()->back()
                ->with('message', 'Attendance record already exists for this employee on this date.')
                ->with('alert', 'error');
        }

        // Get employee details with business unit
        $employee = EmployeeDetail::where('user_id', $request->user_id)
                                 ->with('businessUnit', 'schedule')
                                 ->first();
        if (!$employee) {
            return redirect()->back()
                ->with('message', 'Employee details not found.')
                ->with('alert', 'error');
        }

        // Get schedule times
        $scheduledCheckIn = null;
        $scheduledCheckOut = null;
        if ($employee->schedule) {
            $scheduledCheckIn = $employee->schedule->time_in;
            $scheduledCheckOut = $employee->schedule->time_out;
        }

        // Get business unit timezone
        $timezone = $employee->businessUnit->timezone ?? 'UTC';
        
        // Calculate late minutes and early departure using timezone
        $lateMinutes = 0;
        $earlyDepartureMinutes = 0;
        $totalWorkingMinutes = 0;

        if ($request->check_in_time && $scheduledCheckIn) {
            $checkIn = Carbon::parse($request->attendance_date . ' ' . $request->check_in_time, $timezone);
            $scheduledIn = Carbon::parse($request->attendance_date . ' ' . $scheduledCheckIn, $timezone);
            if ($checkIn->gt($scheduledIn)) {
                $lateMinutes = abs($checkIn->diffInMinutes($scheduledIn, false));
            }
        }
        
        if ($request->check_out_time && $scheduledCheckOut) {
            $checkOut = Carbon::parse($request->attendance_date . ' ' . $request->check_out_time, $timezone);
            $scheduledOut = Carbon::parse($request->attendance_date . ' ' . $scheduledCheckOut, $timezone);
            if ($checkOut->lt($scheduledOut)) {
                $earlyDepartureMinutes = abs($scheduledOut->diffInMinutes($checkOut, false));
            }
        }
        

        if ($request->check_in_time && $request->check_out_time) {
            $checkIn = Carbon::parse($request->attendance_date . ' ' . $request->check_in_time, $timezone);
            $checkOut = Carbon::parse($request->attendance_date . ' ' . $request->check_out_time, $timezone);
            
            // Ensure check-out is after check-in
            if ($checkOut->gt($checkIn)) {
                $totalWorkingMinutes = $checkIn->diffInMinutes($checkOut);
            } else {
                $totalWorkingMinutes = 0; // Invalid time range
            }
        }

        $attendance->update([
            'user_id' => $request->user_id,
            'employee_detail_id' => $employee->id,
            'attendance_date' => $request->attendance_date,
            'check_in_time' => $request->check_in_time,
            'check_out_time' => $request->check_out_time,
            'scheduled_check_in' => $scheduledCheckIn,
            'scheduled_check_out' => $scheduledCheckOut,
            'late_minutes' => $lateMinutes,
            'early_departure_minutes' => $earlyDepartureMinutes,
            'total_working_minutes' => $totalWorkingMinutes,
            'status' => $request->status,
            'notes' => $request->notes,
            'check_in_location' => $request->check_in_location,
            'check_out_location' => $request->check_out_location,
            'device_id' => $request->device_id,
        ]);

        return redirect()->route('admin.attendances.index')
            ->with('message', 'Attendance record updated successfully!')
            ->with('alert', 'success');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $attendance = Attendance::findOrFail($id);
        $attendance->delete();

        return redirect()->route('admin.attendances.index')
            ->with('message', 'Attendance record deleted successfully!')
            ->with('alert', 'success');
    }

    /**
     * Get attendance statistics.
     */
    private function getAttendanceStats(Request $request)
    {
        $query = Attendance::query();

        // Apply same filters as main query
        if ($request->filled('start_date')) {
            $query->where('attendance_date', '>=', $request->start_date);
        }
        if ($request->filled('end_date')) {
            $query->where('attendance_date', '<=', $request->end_date);
        }
        if ($request->filled('employee_id')) {
            $query->where('user_id', $request->employee_id);
        }
        if ($request->filled('business_unit_id')) {
            $query->whereHas('employeeDetail', function($q) use ($request) {
                $q->where('business_unit_id', $request->business_unit_id);
            });
        }
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Default to current month if no date range provided
        if (!$request->filled('start_date') && !$request->filled('end_date')) {
            $query->whereMonth('attendance_date', Carbon::now()->month)
                  ->whereYear('attendance_date', Carbon::now()->year);
        }

        $totalRecords = $query->count();
        $presentCount = $query->where('status', 'present')->count();
        $lateCount = $query->where('status', 'late')->count();
        $absentCount = $query->where('status', 'absent')->count();
        $halfDayCount = $query->where('status', 'half_day')->count();
        $overtimeCount = $query->where('status', 'overtime')->count();

        $totalLateMinutes = $query->sum('late_minutes');
        $totalWorkingMinutes = $query->sum('total_working_minutes');

        return [
            'total_records' => $totalRecords,
            'present_count' => $presentCount,
            'late_count' => $lateCount,
            'absent_count' => $absentCount,
            'half_day_count' => $halfDayCount,
            'overtime_count' => $overtimeCount,
            'total_late_minutes' => $totalLateMinutes,
            'total_working_minutes' => $totalWorkingMinutes,
            'attendance_rate' => $totalRecords > 0 ? round((($presentCount + $lateCount + $halfDayCount + $overtimeCount) / $totalRecords) * 100, 2) : 0,
        ];
    }

    /**
     * Export attendance data.
     */
    public function export(Request $request)
    {
        // This would implement CSV/Excel export functionality
        // For now, return a simple response
        return response()->json(['message' => 'Export functionality will be implemented']);
    }

    /**
     * Show the attendance calendar view.
     */
    public function calendar(Request $request)
    {
        $employees = User::where('type', 'employee')
                        ->where('status', 1)
                        ->with('employeeDetail.businessUnit')
                        ->get();

        $selectedEmployee = null;
        if ($request->filled('employee_id')) {
            $selectedEmployee = User::with('employeeDetail.businessUnit')
                                  ->find($request->employee_id);
        }

        return view('admin.attendances.calendar', compact('employees', 'selectedEmployee'));
    }

    /**
     * Get calendar data for a specific employee.
     */
    public function getCalendarData(Request $request)
    {
        $request->validate([
            'employee_id' => 'required|exists:users,id',
            'start_date' => 'required|date',
            'end_date' => 'required|date|after_or_equal:start_date',
        ]);

        $attendances = Attendance::where('user_id', $request->employee_id)
                                ->whereBetween('attendance_date', [$request->start_date, $request->end_date])
                                ->with(['user', 'employeeDetail.businessUnit'])
                                ->orderBy('attendance_date')
                                ->get();

        $calendarData = [];
        foreach ($attendances as $attendance) {
            $calendarData[] = [
                'id' => $attendance->id,
                'title' => $attendance->getStatusLabel(),
                'start' => $attendance->attendance_date->format('Y-m-d'),
                'allDay' => true,
                'backgroundColor' => $this->getStatusColor($attendance->status),
                'borderColor' => $this->getStatusColor($attendance->status),
                'textColor' => '#ffffff',
                'extendedProps' => [
                    'check_in_time' => $attendance->check_in_time ? $attendance->check_in_time->format('H:i') : 'N/A',
                    'check_out_time' => $attendance->check_out_time ? $attendance->check_out_time->format('H:i') : 'N/A',
                    'scheduled_check_in' => $attendance->scheduled_check_in ? $attendance->scheduled_check_in->format('H:i') : 'N/A',
                    'scheduled_check_out' => $attendance->scheduled_check_out ? $attendance->scheduled_check_out->format('H:i') : 'N/A',
                    'late_minutes' => $attendance->late_minutes,
                    'early_departure_minutes' => $attendance->early_departure_minutes,
                    'total_working_minutes' => $attendance->total_working_minutes,
                    'status' => $attendance->status,
                    'notes' => $attendance->notes,
                    'timezone' => $attendance->getBusinessUnitTimezone(),
                    'formatted_late_time' => $attendance->getFormattedLateTime(),
                    'formatted_early_departure_time' => $attendance->getFormattedEarlyDepartureTime(),
                    'formatted_working_time' => $attendance->getFormattedWorkingTime(),
                ]
            ];
        }

        return response()->json($calendarData);
    }

    /**
     * Get status color for calendar events.
     */
    private function getStatusColor($status)
    {
        return match($status) {
            'present' => '#28a745',
            'absent' => '#dc3545',
            'late' => '#ffc107',
            'half_day' => '#17a2b8',
            'overtime' => '#007bff',
            default => '#6c757d'
        };
    }

}