<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\EmployeeDetail;
use App\Models\BusinessUnit;
use App\Models\Schedule;
use Spatie\Permission\Models\Role;
use DB;
use Hash;
use Illuminate\Support\Facades\Validator;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $data = EmployeeDetail::with(['user', 'businessUnit', 'schedule'])
            ->whereHas('user', function($query) {
                $query->where('status', '!=', 2);
            })
            ->orderBy('id', 'desc')
            ->get();
        return view('admin.employees.index', compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $businessUnits = BusinessUnit::where('status', 1)->get();
        $schedules = Schedule::all();
        return view('admin.employees.create', compact('businessUnits', 'schedules'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        
        // Create a validator instance
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|confirmed|min:8',
            'business_unit_id' => 'required|exists:business_units,id',
            'position' => 'required|string|max:255',
            'work_type' => 'required|in:0,1',
        ]);

        // Check if the validation fails
        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        DB::beginTransaction();
        try {
            // Create the user
            $userData = [
                'name' => $request->name,
                'email' => $request->email,
                'type' => 'employee',
                'password' => Hash::make($request->password),
                'status' => $request->status ?? 1,
            ];
            $user = User::create($userData);
            $user->assignRole('employee');

            // Create employee details
            $employeeData = [
                'user_id' => $user->id,
                'business_unit_id' => $request->business_unit_id,
                'schedule_id' => $request->schedule_id,
                'position' => $request->position,
                'work_type' => $request->work_type,
            ];
            EmployeeDetail::create($employeeData);

            DB::commit();

            return redirect()->route('admin.employees.index')
                ->with('message', 'Employee created successfully!')
                ->with('alert', 'success');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->with('message', 'Something went wrong: ' . $e->getMessage())
                ->with('alert', 'error')
                ->withInput();
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $employee = EmployeeDetail::with(['user', 'businessUnit', 'schedule'])->findOrFail($id);
        return view('admin.employees.view', compact('employee', 'userRole'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $employee = EmployeeDetail::with(['user'])->findOrFail($id);
        $businessUnits = BusinessUnit::where('status', 1)->get();
        $schedules = Schedule::all();
        return view('admin.employees.edit', compact('employee', 'businessUnits', 'schedules'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $employee = EmployeeDetail::findOrFail($id);
        
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email,' . $employee->user_id,
            'business_unit_id' => 'required|exists:business_units,id',
            'position' => 'required|string|max:255',
            'work_type' => 'required|in:0,1',
        ]);

        if ($validator->fails()) {
            return redirect()->back()
                ->withErrors($validator)
                ->withInput();
        }

        DB::beginTransaction();
        try {
            // Update user information
            $userData = [
                'name' => $request->name,
                'email' => $request->email,
                'status' => $request->status ?? 1,
            ];
            
            // Update password only if provided
            if ($request->filled('password')) {
                $userData['password'] = Hash::make($request->password);
            }
            
            $employee->user->update($userData);
            
            // Update employee details
            $employeeData = [
                'business_unit_id' => $request->business_unit_id,
                'schedule_id' => $request->schedule_id,
                'position' => $request->position,
                'work_type' => $request->work_type,
            ];
            $employee->update($employeeData);

            DB::commit();

            return redirect()->route('admin.employees.index')
                ->with('message', 'Employee updated successfully!')
                ->with('alert', 'success');
        } catch (\Exception $e) {
            DB::rollBack();
            return redirect()->back()
                ->with('message', 'Something went wrong: ' . $e->getMessage())
                ->with('alert', 'error')
                ->withInput();
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id)
    {
        try {
            $employee = EmployeeDetail::findOrFail($id);
            
            // Soft delete by updating user status
            $employee->user->status = 2;
            $employee->user->save();

            return redirect()->route('admin.employees.index')
                ->with('message', 'Employee deleted successfully.')
                ->with('alert', 'success');
        } catch (\Exception $e) {
            return redirect()->back()
                ->with('message', 'Something went wrong: ' . $e->getMessage())
                ->with('alert', 'error');
        }
    }
}

