<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Carbon\Carbon;
use App\Models\Attendance;
use App\Models\EmployeeDetail;
use App\Models\Schedule;
use App\Models\Media;

class AttendanceController extends Controller
{
    /**
     * Employee Check-in API
     */
    public function checkIn(Request $request)
    {
        try {
            $user = $request->user();
            
            // Get employee details first to determine work type
            $employee = EmployeeDetail::with(['businessUnit', 'schedule'])
                ->where('user_id', $user->id)
                ->first();

            if (!$employee) {
                return response()->json([
                    'success' => false,
                    'message' => 'Employee details not found'
                ], 404);
            }

            // Dynamic validation based on work type
            $validationRules = [
                'device_id' => 'required|string|max:255',
                'location' => 'nullable|string|max:255',
                'notes' => 'nullable|string|max:500',
            ];

            // For outside employees (work_type = 1), require image and location coordinates
            if ($employee->work_type == 1) {
                $validationRules['image'] = 'required|image|mimes:jpeg,png,jpg,gif|max:5120'; // 5MB max
                $validationRules['latitude'] = 'required|numeric|between:-90,90';
                $validationRules['longitude'] = 'required|numeric|between:-180,180';
            }
            
            // For inside employees (work_type = 0), require location coordinates for verification
            if ($employee->work_type == 0) {
                $validationRules['latitude'] = 'required|numeric|between:-90,90';
                $validationRules['longitude'] = 'required|numeric|between:-180,180';
            }

            // Validate the request
            $validator = Validator::make($request->all(), $validationRules);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Get business unit timezone
            $businessUnitTimezone = $employee->businessUnit->timezone ?? 'UTC';
            $today = Carbon::today($businessUnitTimezone);
            $now = Carbon::now();

            // Check if already checked in today
            $existingAttendance = Attendance::where('user_id', $user->id)
                ->where('attendance_date', $today)
                ->first();

            if ($existingAttendance && $existingAttendance->check_in_time) {
                return response()->json([
                    'success' => false,
                    'message' => 'You have already checked in today',
                    'data' => [
                        'check_in_time' => $existingAttendance->check_in_time->format('H:i:s'),
                        'attendance_date' => $existingAttendance->attendance_date->format('Y-m-d')
                    ]
                ], 409);
            }

            // Get scheduled times
            $scheduledCheckIn = null;
            $scheduledCheckOut = null;
            if ($employee->schedule) {
                $scheduledCheckIn = Carbon::createFromFormat('H:i:s', $employee->schedule->time_in);
                $scheduledCheckOut = Carbon::createFromFormat('H:i:s', $employee->schedule->time_out);
            }

            // Get business unit timezone
            $businessUnitTimezone = $employee->businessUnit->timezone ?? 'UTC';
            
            // Calculate if late
            $lateMinutes = 0;
            if ($scheduledCheckIn) {
                // Create new Carbon instances in the business unit timezone for comparison
                $checkInTime = Carbon::now($businessUnitTimezone);
                $scheduledTime = Carbon::today($businessUnitTimezone)
                    ->setTimeFromTimeString($scheduledCheckIn->format('H:i:s'));
                
                if ($checkInTime->gt($scheduledTime)) {
                    $lateMinutes = $scheduledTime->diffInMinutes($checkInTime);

                }
            }

            // Determine status
            $status = 'present';
            if ($lateMinutes > 0) {
                $status = 'late';
            }
            $actualCheckInTime = Carbon::now($businessUnitTimezone);

            // Handle image upload and location verification based on work type
            $imageData = null;
            if ($employee->work_type == 1) {
                // For outside employees: Upload image and record location (no verification)
                $imageData = $this->handleImageUpload($request->file('image'), $user->id, 'check_in');
                // Just record the location, no verification needed
            } elseif ($employee->work_type == 0) {
                // For inside employees: Verify location against business unit
                $locationVerified = $this->verifyLocation($request->latitude, $request->longitude, $employee);
                
                if (!$locationVerified) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Location verification failed. Please ensure you are at the correct work location.'
                    ], 400);
                }
            }

            // Create or update attendance record
            $attendanceData = [
                'user_id' => $user->id,
                'employee_detail_id' => $employee->id,
                'attendance_date' => $today,
                'check_in_time' => $actualCheckInTime->format('H:i:s'),
                'scheduled_check_in' => $scheduledCheckIn ? $scheduledCheckIn->format('H:i:s') : null,
                'scheduled_check_out' => $scheduledCheckOut ? $scheduledCheckOut->format('H:i:s') : null,
                'late_minutes' => $lateMinutes,
                'status' => $status,
                'check_in_location' => $request->location,
                'device_id' => $request->device_id,
                'notes' => $request->notes,
            ];

            if ($existingAttendance) {
                $existingAttendance->update($attendanceData);
                $attendance = $existingAttendance;
            } else {
                $attendance = Attendance::create($attendanceData);
            }

            // Update media record with attendance ID if image was uploaded
            if ($imageData) {
                $imageData->update(['parent_id' => $attendance->id]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Check-in successful',
                'data' => [
                    'attendance_id' => $attendance->id,
                    'check_in_time' => $attendance->check_in_time->format('H:i:s'),
                    'attendance_date' => $attendance->attendance_date->format('Y-m-d'),
                    'late_minutes' => $attendance->late_minutes,
                    'status' => $attendance->status,
                    'status_label' => $attendance->getStatusLabel(),
                    'scheduled_check_in' => $attendance->scheduled_check_in,
                    'is_late' => $lateMinutes > 0,
                    'late_time_formatted' => $attendance->getFormattedLateTime(),
                    'timezone' => $employee->businessUnit->timezone ?? 'UTC',
                    'work_type' => $employee->work_type,
                    'work_type_label' => $employee->getWorkTypeLabel(),
                    'image_uploaded' => $imageData ? true : false,
                    'image_url' => $imageData ? $imageData->file_url : null
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred during check-in',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Employee Check-out API
     */
    public function checkOut(Request $request)
    {
        // try {
            $user = $request->user();
            
            // Get employee details first to determine work type
            $employee = EmployeeDetail::with(['businessUnit', 'schedule'])
                ->where('user_id', $user->id)
                ->first();

            if (!$employee) {
                return response()->json([
                    'success' => false,
                    'message' => 'Employee details not found'
                ], 404);
            }

            // Dynamic validation based on work type
            $validationRules = [
                'device_id' => 'required|string|max:255',
                'location' => 'nullable|string|max:255',
                'notes' => 'nullable|string|max:500',
            ];

            // For outside employees (work_type = 1), require image and location coordinates
            if ($employee->work_type == 1) {
                $validationRules['image'] = 'required|image|mimes:jpeg,png,jpg,gif|max:5120'; // 5MB max
                $validationRules['latitude'] = 'required|numeric|between:-90,90';
                $validationRules['longitude'] = 'required|numeric|between:-180,180';
            }
            
            // For inside employees (work_type = 0), require location coordinates for verification
            if ($employee->work_type == 0) {
                $validationRules['latitude'] = 'required|numeric|between:-90,90';
                $validationRules['longitude'] = 'required|numeric|between:-180,180';
            }

            // Validate the request
            $validator = Validator::make($request->all(), $validationRules);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $businessUnitTimezone = $employee->businessUnit->timezone ?? 'UTC';
            $today = Carbon::today($businessUnitTimezone);
            $now = Carbon::now();

            // Handle image upload and location verification based on work type
            $imageData = null;
            if ($employee->work_type == 1) {
                // For outside employees: Upload image and record location (no verification)
                $imageData = $this->handleImageUpload($request->file('image'), $user->id, 'check_out');
                // Just record the location, no verification needed
            } elseif ($employee->work_type == 0) {
                // For inside employees: Verify location against business unit
                $locationVerified = $this->verifyLocation($request->latitude, $request->longitude, $employee);
                
                if (!$locationVerified) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Location verification failed. Please ensure you are at the correct work location.'
                    ], 400);
                }
            }
            // Check if checked in today
            $attendance = Attendance::where('user_id', $user->id)
                ->where('attendance_date', $today)
                ->first();

            if (!$attendance || !$attendance->check_in_time) {
                return response()->json([
                    'success' => false,
                    'message' => 'You must check in before checking out'
                ], 400);
            }

            // Check if already checked out today
            if ($attendance->check_out_time) {
                return response()->json([
                    'success' => false,
                    'message' => 'You have already checked out today',
                    'data' => [
                        'check_out_time' => $attendance->check_out_time->format('H:i:s'),
                        'attendance_date' => $attendance->attendance_date->format('Y-m-d')
                    ]
                ], 409);
            }



// Get actual checkout time in business unit timezone
$actualCheckOutTime = Carbon::now($businessUnitTimezone);

// Calculate early departure
$earlyDepartureMinutes = 0;
if ($attendance->scheduled_check_out) {
    // Handle both time and datetime formats
    $scheduledTimeStr = $attendance->scheduled_check_out;
    if (is_object($scheduledTimeStr)) {
        $scheduledTimeStr = $scheduledTimeStr->format('H:i:s');
    }
    
    // Create scheduled checkout time in business unit timezone
    $scheduledCheckOutTime = Carbon::today($businessUnitTimezone)
        ->setTimeFromTimeString($scheduledTimeStr);
    
    // If checking out BEFORE scheduled time = early departure
    if ($actualCheckOutTime->lt($scheduledCheckOutTime)) {
        // Calculate from checkout time TO scheduled time (positive result)
        $earlyDepartureMinutes = $actualCheckOutTime->diffInMinutes($scheduledCheckOutTime);
    }
}

// Calculate total working minutes
$totalWorkingMinutes = 0;
if ($attendance->check_in_time) {
    // Handle both time and datetime formats for check_in_time
    $checkInTimeStr = $attendance->check_in_time;
    if (is_object($checkInTimeStr)) {
        $checkInTimeStr = $checkInTimeStr->format('H:i:s');
    }
    
    // Create check-in time in business unit timezone
    $checkInTime = Carbon::today($businessUnitTimezone)
        ->setTimeFromTimeString($checkInTimeStr);
    
    // Calculate working time
    if ($actualCheckOutTime->gt($checkInTime)) {
        $totalWorkingMinutes = $checkInTime->diffInMinutes($actualCheckOutTime);
    }
}

// Update status based on working hours
$status = $attendance->status;
if ($totalWorkingMinutes > 0) {
    $scheduledMinutes = 0;
    if ($attendance->scheduled_check_in && $attendance->scheduled_check_out) {
        // Handle both time and datetime formats for scheduled times
        $scheduledInStr = $attendance->scheduled_check_in;
        $scheduledOutStr = $attendance->scheduled_check_out;
        
        if (is_object($scheduledInStr)) {
            $scheduledInStr = $scheduledInStr->format('H:i:s');
        }
        if (is_object($scheduledOutStr)) {
            $scheduledOutStr = $scheduledOutStr->format('H:i:s');
        }
        
        $scheduledIn = Carbon::createFromFormat('H:i:s', $scheduledInStr);
        $scheduledOut = Carbon::createFromFormat('H:i:s', $scheduledOutStr);
        $scheduledMinutes = $scheduledIn->diffInMinutes($scheduledOut);
    }
    
    if ($totalWorkingMinutes >= $scheduledMinutes * 0.5 && $totalWorkingMinutes < $scheduledMinutes * 0.8) {
        $status = 'half_day';
    } elseif ($totalWorkingMinutes > $scheduledMinutes * 1.2) {
        $status = 'overtime';
    }
}

            // Update attendance record
            $attendance->update([
                'check_out_time' => $actualCheckOutTime->format('H:i:s'),
                'early_departure_minutes' => $earlyDepartureMinutes,
                'total_working_minutes' => $totalWorkingMinutes,
                'status' => $status,
                'check_out_location' => $request->location,
                'device_id' => $request->device_id,
                'notes' => $attendance->notes ? $attendance->notes . ' | ' . $request->notes : $request->notes,
            ]);

            // Update media record with attendance ID if image was uploaded
            if ($imageData) {
                $imageData->update(['parent_id' => $attendance->id]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Check-out successful',
                'data' => [
                    'attendance_id' => $attendance->id,
                    'check_in_time' => $attendance->check_in_time->format('H:i:s'),
                    'check_out_time' => $attendance->check_out_time->format('H:i:s'),
                    'attendance_date' => $attendance->attendance_date->format('Y-m-d'),
                    'total_working_minutes' => $attendance->total_working_minutes,
                    'working_time_formatted' => $attendance->getFormattedWorkingTime(),
                    'early_departure_minutes' => $attendance->early_departure_minutes,
                    'early_departure_formatted' => $attendance->getFormattedEarlyDepartureTime(),
                    'status' => $attendance->status,
                    'status_label' => $attendance->getStatusLabel(),
                    'is_early_departure' => $earlyDepartureMinutes > 0,
                    'timezone' => $employee->businessUnit->timezone ?? 'UTC',
                    'work_type' => $employee->work_type,
                    'work_type_label' => $employee->getWorkTypeLabel(),
                    'image_uploaded' => $imageData ? true : false,
                    'image_url' => $imageData ? $imageData->file_url : null
                ]
            ], 200);

        // } catch (\Exception $e) {
        //     return response()->json([
        //         'success' => false,
        //         'message' => 'An error occurred during check-out',
        //         'error' => $e->getMessage()
        //     ], 500);
        // }
    }

    /**
     * Get Today's Attendance Status API
     */
    public function getTodayAttendance(Request $request)
    {
        try {
            $user = $request->user();
            $businessUnitTimezone = $user->employeeDetail?->businessUnit?->timezone ?? 'UTC';
            $today = Carbon::today($businessUnitTimezone);
            if (!$user->employeeDetail) {
                return response()->json([
                    'success' => false,
                    'message' => 'Employee details not found'
                ], 404);
            }

            // Get today's attendance
            $attendance = Attendance::with(['employeeDetail.businessUnit', 'employeeDetail.schedule'])
                ->where('user_id', $user->id)
                ->where('attendance_date', $today)
                ->first();

            if (!$attendance) {
                return response()->json([
                    'success' => true,
                    'message' => 'No attendance record for today',
                    'data' => [
                        'attendance_date' => $today->format('Y-m-d'),
                        'is_checked_in' => false,
                        'is_checked_out' => false,
                        'status' => 'not_started'
                    ]
                ], 200);
            }

            return response()->json([
                'success' => true,
                'message' => 'Today\'s attendance retrieved successfully',
                'data' => [
                    'attendance_id' => $attendance->id,
                    'attendance_date' => $attendance->attendance_date->format('Y-m-d'),
                    'check_in_time' => $attendance->check_in_time ? $attendance->check_in_time->format('H:i:s') : null,
                    'check_out_time' => $attendance->check_out_time ? $attendance->check_out_time->format('H:i:s') : null,
                    'scheduled_check_in' => $attendance->scheduled_check_in,
                    'scheduled_check_out' => $attendance->scheduled_check_out,
                    'late_minutes' => $attendance->late_minutes,
                    'early_departure_minutes' => $attendance->early_departure_minutes,
                    'total_working_minutes' => $attendance->total_working_minutes,
                    'status' => $attendance->status,
                    'status_label' => $attendance->getStatusLabel(),
                    'is_checked_in' => !is_null($attendance->check_in_time),
                    'is_checked_out' => !is_null($attendance->check_out_time),
                    'late_time_formatted' => $attendance->getFormattedLateTime(),
                    'early_departure_formatted' => $attendance->getFormattedEarlyDepartureTime(),
                    'working_time_formatted' => $attendance->getFormattedWorkingTime(),
                    'timezone' => $attendance->getBusinessUnitTimezone(),
                    'notes' => $attendance->notes
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving attendance',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get Attendance History API
     */
    public function getAttendanceHistory(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'start_date' => 'nullable|date',
                'end_date' => 'nullable|date|after_or_equal:start_date',
                'limit' => 'nullable|integer|min:1|max:100',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = $request->user();
            $limit = $request->input('limit', 30);
            $startDate = $request->input('start_date', Carbon::now()->subDays(30)->format('Y-m-d'));
            $endDate = $request->input('end_date', Carbon::now()->format('Y-m-d'));

            $query = Attendance::with(['employeeDetail.businessUnit', 'employeeDetail.schedule'])
                ->where('user_id', $user->id)
                ->whereBetween('attendance_date', [$startDate, $endDate])
                ->orderBy('attendance_date', 'desc');

            $attendances = $query->limit($limit)->get();

            $formattedAttendances = $attendances->map(function ($attendance) {
                return [
                    'attendance_id' => $attendance->id,
                    'attendance_date' => $attendance->attendance_date->format('Y-m-d'),
                    'check_in_time' => $attendance->check_in_time ? $attendance->check_in_time->format('H:i:s') : null,
                    'check_out_time' => $attendance->check_out_time ? $attendance->check_out_time->format('H:i:s') : null,
                    'scheduled_check_in' => $attendance->scheduled_check_in,
                    'scheduled_check_out' => $attendance->scheduled_check_out,
                    'late_minutes' => $attendance->late_minutes,
                    'early_departure_minutes' => $attendance->early_departure_minutes,
                    'total_working_minutes' => $attendance->total_working_minutes,
                    'status' => $attendance->status,
                    'status_label' => $attendance->getStatusLabel(),
                    'late_time_formatted' => $attendance->getFormattedLateTime(),
                    'early_departure_formatted' => $attendance->getFormattedEarlyDepartureTime(),
                    'working_time_formatted' => $attendance->getFormattedWorkingTime(),
                    'timezone' => $attendance->getBusinessUnitTimezone(),
                    'notes' => $attendance->notes
                ];
            });

            return response()->json([
                'success' => true,
                'message' => 'Attendance history retrieved successfully',
                'data' => [
                    'attendances' => $formattedAttendances,
                    'total_records' => $attendances->count(),
                    'date_range' => [
                        'start_date' => $startDate,
                        'end_date' => $endDate
                    ],
                    'pagination' => [
                        'limit' => $limit,
                        'has_more' => $attendances->count() >= $limit
                    ]
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving attendance history',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Handle image upload for attendance verification
     */
    private function handleImageUpload($imageFile, $userId, $type)
    {
        try {
            // Validate that the file exists and is valid
            if (!$imageFile || !$imageFile->isValid()) {
                throw new \Exception('Invalid file upload');
            }
            
            // Generate unique filename
            $filename = $userId . '_' . $type . '_' . time() . '.' . $imageFile->getClientOriginalExtension();
            
            // Create directory if it doesn't exist
            $uploadPath = public_path('assets/admin/attendance_images');
            if (!file_exists($uploadPath)) {
                mkdir($uploadPath, 0755, true);
            }
            
            // Get file contents and save directly
            $fileContents = file_get_contents($imageFile->getRealPath());
            if ($fileContents === false) {
                throw new \Exception('Could not read uploaded file');
            }
            
            $fullPath = $uploadPath . '/' . $filename;
            $saved = file_put_contents($fullPath, $fileContents);
            
            if ($saved === false) {
                throw new \Exception('Could not save file to destination');
            }
            
            // Create media record with public path
            $media = Media::create([
                'parent_class' => 'App\\Models\\Attendance',
                'parent_id' => 0, // Will be updated after attendance is created
                'file_type' => 'image',
                'file_path' => 'assets/admin/attendance_images/' . $filename,
                'file_name' => $filename,
                'original_name' => $imageFile->getClientOriginalName(),
                'mime_type' => $imageFile->getMimeType(),
                'file_size' => $imageFile->getSize(),
                'metadata' => [
                    'upload_type' => $type,
                    'uploaded_at' => now()->toISOString(),
                    'user_id' => $userId
                ]
            ]);
            
            return $media;
        } catch (\Exception $e) {
            throw new \Exception('Failed to upload image: ' . $e->getMessage());
        }
    }

    /**
     * Verify location for outside employees
     */
    private function verifyLocation($latitude, $longitude, $employee)
    {
        try {
            // Get business unit location
            $businessUnit = $employee->businessUnit;
            
            if (!$businessUnit->latitude || !$businessUnit->longitude) {
                // If no location is set for business unit, allow any location
                return true;
            }
            
            // Calculate distance between employee location and business unit location
            $distance = $this->calculateDistance(
                $latitude, 
                $longitude, 
                $businessUnit->latitude, 
                $businessUnit->longitude
            );
            
            // Allow check-in if within 100 meters of business unit location
            $allowedDistance = 100; // meters
            
            return $distance <= $allowedDistance;
        } catch (\Exception $e) {
            // If location verification fails, allow check-in but log the error
            \Log::error('Location verification failed: ' . $e->getMessage());
            return true;
        }
    }

    /**
     * Calculate distance between two coordinates using Haversine formula
     */
    private function calculateDistance($lat1, $lon1, $lat2, $lon2)
    {
        $earthRadius = 6371000; // Earth's radius in meters
        
        $dLat = deg2rad($lat2 - $lat1);
        $dLon = deg2rad($lon2 - $lon1);
        
        $a = sin($dLat/2) * sin($dLat/2) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLon/2) * sin($dLon/2);
        $c = 2 * atan2(sqrt($a), sqrt(1-$a));
        
        return $earthRadius * $c;
    }
}
