<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\EmployeeDetail;

class AuthController extends Controller
{
    /**
     * User Login API
     */
    public function login(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|string|min:6',
                'device_id' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Attempt to authenticate user
            if (!Auth::attempt($request->only('email', 'password'))) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid credentials'
                ], 401);
            }

            $user = Auth::user();

            // Check if user is active
            if ($user->status !== 1) {
                Auth::logout();
                return response()->json([
                    'success' => false,
                    'message' => 'Account is not active'
                ], 401);
            }

            // Check if user has ever logged in before (device binding check)
            $hasLoggedInBefore = \DB::table('sessions')
                ->where('user_id', $user->id)
                ->exists();

            if ($hasLoggedInBefore) {
                // User has logged in before, check if this is the same device
                $registeredDevice = \DB::table('sessions')
                    ->where('user_id', $user->id)
                    ->orderBy('last_activity', 'desc')
                    ->first();

                if ($registeredDevice && $registeredDevice->device_id !== $request->device_id) {
                    return response()->json([
                        'success' => false,
                        'message' => 'This account is bound to another device. You can only login from the originally registered device.',
                        'code' => 'DEVICE_NOT_AUTHORIZED'
                    ], 403); // 403 Forbidden
                }

                // Check if user is currently logged in on another device
                $activeSession = \DB::table('sessions')
                    ->where('user_id', $user->id)
                    ->where('device_id', '!=', $request->device_id)
                    ->where('last_activity', '>', time() - 3600) // Active within last hour
                    ->first();

                if ($activeSession) {
                    return response()->json([
                        'success' => false,
                        'message' => 'You are already logged in on another device. Please logout from the other device first.',
                        'code' => 'ALREADY_LOGGED_IN'
                    ], 409); // 409 Conflict
                }
            }

            // Get employee details
            $employee = EmployeeDetail::with(['businessUnit', 'schedule'])
                ->where('user_id', $user->id)
                ->first();

            if (!$employee) {
                Auth::logout();
                return response()->json([
                    'success' => false,
                    'message' => 'Employee details not found'
                ], 404);
            }

            // Revoke all existing tokens for this device
            $user->tokens()->where('name', 'mobile-app-' . $request->device_id)->delete();

            // Create new token
            $token = $user->createToken('mobile-app-' . $request->device_id, ['*'], now()->addYears(10))->plainTextToken;

            // Update session with device_id
            $session = \DB::table('sessions')
                ->where('user_id', $user->id)
                ->first();

            if ($session) {
                \DB::table('sessions')
                    ->where('id', $session->id)
                    ->update(['device_id' => $request->device_id]);
            } else {
                // Create new session record for device binding
                \DB::table('sessions')->insert([
                    'id' => \Str::random(40),
                    'user_id' => $user->id,
                    'device_id' => $request->device_id,
                    'ip_address' => $request->ip(),
                    'user_agent' => $request->userAgent(),
                    'payload' => base64_encode(serialize([])),
                    'last_activity' => time(),
                ]);
            }

            return response()->json([
                'success' => true,
                'message' => 'Login successful',
                'data' => [
                    'user' => [
                        'id' => $user->id,
                        'name' => $user->name,
                        'email' => $user->email,
                        'type' => $user->type,
                        'status' => $user->status,
                    ],
                    'employee' => [
                        'id' => $employee->id,
                        'employee_id' => $employee->employee_id,
                        'work_type' => $employee->work_type,
                        'work_type_label' => $employee->getWorkTypeLabel(),
                        'business_unit' => $employee->businessUnit ? [
                            'id' => $employee->businessUnit->id,
                            'name' => $employee->businessUnit->name,
                            'timezone' => $employee->businessUnit->timezone,
                        ] : null,
                        'schedule' => $employee->schedule ? [
                            'id' => $employee->schedule->id,
                            'name' => $employee->schedule->name,
                            'time_in' => $employee->schedule->time_in,
                            'time_out' => $employee->schedule->time_out,
                        ] : null,
                    ],
                    'token' => $token,
                    'token_type' => 'Bearer',
                    'expires_at' => now()->addYears(10)->toISOString(),
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred during login',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * User Logout API
     */
    public function logout(Request $request)
    {
        try {
            $user = $request->user();
            
            // Revoke current token
            $request->user()->currentAccessToken()->delete();

            return response()->json([
                'success' => true,
                'message' => 'Logout successful'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred during logout',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get User Profile API
     */
    public function profile(Request $request)
    {
        try {
            $user = $request->user();
            
            $employee = EmployeeDetail::with(['businessUnit', 'schedule'])
                ->where('user_id', $user->id)
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Profile retrieved successfully',
                'data' => [
                    'user' => [
                        'id' => $user->id,
                        'name' => $user->name,
                        'email' => $user->email,
                        'type' => $user->type,
                        'status' => $user->status,
                    ],
                    'employee' => $employee ? [
                        'id' => $employee->id,
                        'employee_id' => $employee->employee_id,
                        'work_type' => $employee->work_type,
                        'work_type_label' => $employee->getWorkTypeLabel(),
                        'business_unit' => $employee->businessUnit ? [
                            'id' => $employee->businessUnit->id,
                            'name' => $employee->businessUnit->name,
                            'timezone' => $employee->businessUnit->timezone,
                        ] : null,
                        'schedule' => $employee->schedule ? [
                            'id' => $employee->schedule->id,
                            'name' => $employee->schedule->name,
                            'time_in' => $employee->schedule->time_in,
                            'time_out' => $employee->schedule->time_out,
                        ] : null,
                    ] : null,
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving profile',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Revoke All Tokens API
     */
    public function revokeAllTokens(Request $request)
    {
        try {
            $user = $request->user();
            
            // Revoke all tokens for this user
            $user->tokens()->delete();

            return response()->json([
                'success' => true,
                'message' => 'All tokens revoked successfully'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while revoking tokens',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Logout All Devices API
     */
    public function logoutAllDevices(Request $request)
    {
        try {
            $user = $request->user();
            
            // Revoke all tokens for this user
            $user->tokens()->delete();

            // Clear all sessions for this user
            \DB::table('sessions')
                ->where('user_id', $user->id)
                ->delete();

            return response()->json([
                'success' => true,
                'message' => 'Logged out from all devices successfully'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while logging out from all devices',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check Login Status API
     */
    public function checkLoginStatus(Request $request)
    {
        try {
            $user = $request->user();
            
            // Get active sessions
            $activeSessions = \DB::table('sessions')
                ->where('user_id', $user->id)
                ->where('last_activity', '>', time() - 3600) // Active within last hour
                ->get();

            return response()->json([
                'success' => true,
                'message' => 'Login status retrieved successfully',
                'data' => [
                    'is_logged_in' => true,
                    'active_sessions_count' => $activeSessions->count(),
                    'current_device_id' => $request->header('X-Device-ID'),
                    'last_activity' => $user->updated_at->toISOString(),
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while checking login status',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get Registered Device API
     */
    public function getRegisteredDevice(Request $request)
    {
        try {
            $user = $request->user();
            
            // Get the registered device
            $registeredDevice = \DB::table('sessions')
                ->where('user_id', $user->id)
                ->orderBy('last_activity', 'desc')
                ->first();

            return response()->json([
                'success' => true,
                'message' => 'Registered device retrieved successfully',
                'data' => [
                    'device_id' => $registeredDevice ? $registeredDevice->device_id : null,
                    'last_activity' => $registeredDevice ? date('Y-m-d H:i:s', $registeredDevice->last_activity) : null,
                    'ip_address' => $registeredDevice ? $registeredDevice->ip_address : null,
                    'user_agent' => $registeredDevice ? $registeredDevice->user_agent : null,
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving registered device',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Reset Device Binding API
     */
    public function resetDeviceBinding(Request $request)
    {
        try {
            $user = $request->user();
            
            // Clear all sessions for this user
            \DB::table('sessions')
                ->where('user_id', $user->id)
                ->delete();

            // Revoke all tokens for this user
            $user->tokens()->delete();

            return response()->json([
                'success' => true,
                'message' => 'Device binding reset successfully. You can now login from any device.'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while resetting device binding',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}