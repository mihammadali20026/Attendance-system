<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use App\Models\User;
use App\Models\EmployeeDetail;
use App\Models\BusinessUnit;
use App\Models\Schedule;

class EmployeeAuthController extends Controller
{
    /**
     * Employee Login API
     */
    public function login(Request $request)
    {
        try {
            // Validate the request
            $validator = Validator::make($request->all(), [
                'email' => 'required|email',
                'password' => 'required|string|min:6',
                'device_id' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            // Check if user exists and is an employee
            $user = User::where('email', $request->email)
                ->where('type', 'employee')
                ->first();

            if (!$user) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid credentials or account not found'
                ], 401);
            }

            // Check if user account is active
            if ($user->status != 1) {
                return response()->json([
                    'success' => false,
                    'message' => 'Account is inactive. Please contact administrator.'
                ], 403);
            }

            // Verify password
            if (!Hash::check($request->password, $user->password)) {
                return response()->json([
                    'success' => false,
                    'message' => 'Invalid credentials'
                ], 401);
            }

            // Check if user has ever logged in before (device binding check)
            $hasLoggedInBefore = \DB::table('sessions')
                ->where('user_id', $user->id)
                ->exists();

            if ($hasLoggedInBefore) {
                // User has logged in before, check if this is the same device
                $registeredDevice = \DB::table('sessions')
                    ->where('user_id', $user->id)
                    ->orderBy('last_activity', 'desc')
                    ->first();

                if ($registeredDevice && $registeredDevice->device_id !== $request->device_id) {
                    return response()->json([
                        'success' => false,
                        'message' => 'This account is bound to another device. You can only login from the originally registered device.',
                        'code' => 'DEVICE_NOT_AUTHORIZED'
                    ], 403); // 403 Forbidden
                }

                // Check if user is currently logged in on another device
                $activeSession = \DB::table('sessions')
                    ->where('user_id', $user->id)
                    ->where('device_id', '!=', $request->device_id)
                    ->where('last_activity', '>', time() - 3600) // Active within last hour
                    ->first();

                if ($activeSession) {
                    return response()->json([
                        'success' => false,
                        'message' => 'You are already logged in on another device. Please logout from the other device first.',
                        'code' => 'ALREADY_LOGGED_IN'
                    ], 409); // 409 Conflict
                }
            }

            // Get employee details
            $employee = EmployeeDetail::with(['businessUnit', 'schedule'])
                ->where('user_id', $user->id)
                ->first();

            if (!$employee) {
                return response()->json([
                    'success' => false,
                    'message' => 'Employee details not found'
                ], 404);
            }

            // Create simple token for API authentication
            $token = base64_encode($user->id . '|' . time() . '|' . $request->device_id);

            // Remove any existing sessions for this user (single device login)
            \DB::table('sessions')->where('user_id', $user->id)->delete();

            // Generate session ID
            $sessionId = Str::random(40);
            
            // Store device_id in session
            $sessionData = [
                'id' => $sessionId,
                'user_id' => $user->id,
                'device_id' => $request->device_id,
                'ip_address' => $request->ip(),
                'user_agent' => $request->userAgent(),
                'payload' => '', // Empty payload for API sessions
                'last_activity' => time(),
            ];

            // Store in sessions table
            \DB::table('sessions')->insert($sessionData);

            // Prepare response data
            $responseData = [
                'success' => true,
                'message' => 'Login successful',
                'data' => [
                    'user' => [
                        'id' => $user->id,
                        'name' => $user->name,
                        'email' => $user->email,
                    ],
                    'employee' => [
                        'id' => $employee->id,
                        'position' => $employee->position,
                        'work_type' => $employee->work_type,
                        'work_type_label' => $employee->getWorkTypeLabel(),
                        'business_unit' => [
                            'id' => $employee->businessUnit->id,
                            'name' => $employee->businessUnit->name,
                            'timezone' => $employee->businessUnit->timezone,
                            'timezone_label' => $employee->businessUnit->getTimezoneLabel(),
                        ],
                        'schedule' => $employee->schedule ? [
                            'id' => $employee->schedule->id,
                            'name' => $employee->schedule->name,
                            'time_in' => $employee->schedule->time_in,
                            'time_out' => $employee->schedule->time_out,
                        ] : null,
                    ],
                    'device_id' => $request->device_id,
                    'token' => $token,
                    'token_type' => 'Bearer',
                ]
            ];

            return response()->json($responseData, 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred during login',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Employee Logout API
     */
    public function logout(Request $request)
    {
        try {
            // Get device_id from request
            $deviceId = $request->input('device_id');
            
            if ($deviceId) {
                // Remove session for this device only
                \DB::table('sessions')
                    ->where('user_id', $request->user()->id)
                    ->where('device_id', $deviceId)
                    ->delete();
            }

            // Simple token logout - just clear the session
            // In a real implementation, you would invalidate the token

            return response()->json([
                'success' => true,
                'message' => 'Logout successful'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred during logout',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Logout from all devices API
     */
    public function logoutAllDevices(Request $request)
    {
        try {
            $user = $request->user();
            
            // Remove all sessions for this user
            \DB::table('sessions')
                ->where('user_id', $user->id)
                ->delete();

            // Simple token logout - just clear the session
            // In a real implementation, you would invalidate all tokens

            return response()->json([
                'success' => true,
                'message' => 'Logged out from all devices successfully'
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred during logout from all devices',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get Employee Profile API
     */
    public function profile(Request $request)
    {
        try {
            $user = $request->user();
            $employee = EmployeeDetail::with(['businessUnit', 'schedule'])
                ->where('user_id', $user->id)
                ->first();

            if (!$employee) {
                return response()->json([
                    'success' => false,
                    'message' => 'Employee details not found'
                ], 404);
            }

            $responseData = [
                'success' => true,
                'data' => [
                    'user' => [
                        'id' => $user->id,
                        'name' => $user->name,
                        'email' => $user->email,
                        'type' => $user->type,
                        'status' => $user->status,
                    ],
                    'employee' => [
                        'id' => $employee->id,
                        'position' => $employee->position,
                        'work_type' => $employee->work_type,
                        'work_type_label' => $employee->getWorkTypeLabel(),
                        'business_unit' => [
                            'id' => $employee->businessUnit->id,
                            'name' => $employee->businessUnit->name,
                            'timezone' => $employee->businessUnit->timezone,
                            'timezone_label' => $employee->businessUnit->getTimezoneLabel(),
                        ],
                        'schedule' => $employee->schedule ? [
                            'id' => $employee->schedule->id,
                            'name' => $employee->schedule->name,
                            'time_in' => $employee->schedule->time_in,
                            'time_out' => $employee->schedule->time_out,
                        ] : null,
                    ],
                ]
            ];

            return response()->json($responseData, 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while fetching profile',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Update Device ID API
     */
    public function updateDeviceId(Request $request)
    {
        try {
            $validator = Validator::make($request->all(), [
                'device_id' => 'required|string|max:255',
            ]);

            if ($validator->fails()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Validation failed',
                    'errors' => $validator->errors()
                ], 422);
            }

            $user = $request->user();
            $newDeviceId = $request->device_id;

            // Update device_id in session
            \DB::table('sessions')
                ->where('user_id', $user->id)
                ->update([
                    'device_id' => $newDeviceId,
                    'last_activity' => time(),
                ]);

            return response()->json([
                'success' => true,
                'message' => 'Device ID updated successfully',
                'data' => [
                    'device_id' => $newDeviceId
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while updating device ID',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Check Login Status API
     */
    public function checkLoginStatus(Request $request)
    {
        try {
            $user = $request->user();
            
            // Check if user has active session
            $activeSession = \DB::table('sessions')
                ->where('user_id', $user->id)
                ->where('last_activity', '>', time() - 3600) // Active within last hour
                ->first();

            if (!$activeSession) {
                return response()->json([
                    'success' => false,
                    'message' => 'No active session found',
                    'code' => 'NO_ACTIVE_SESSION'
                ], 401);
            }

            return response()->json([
                'success' => true,
                'message' => 'User is logged in',
                'data' => [
                    'user_id' => $user->id,
                    'device_id' => $activeSession->device_id,
                    'last_activity' => $activeSession->last_activity,
                    'ip_address' => $activeSession->ip_address
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while checking login status',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Get Registered Device Info API
     */
    public function getRegisteredDevice(Request $request)
    {
        try {
            $user = $request->user();
            
            // Get the first registered device (oldest session)
            $registeredDevice = \DB::table('sessions')
                ->where('user_id', $user->id)
                ->orderBy('last_activity', 'asc')
                ->first();

            if (!$registeredDevice) {
                return response()->json([
                    'success' => false,
                    'message' => 'No registered device found',
                    'code' => 'NO_REGISTERED_DEVICE'
                ], 404);
            }

            return response()->json([
                'success' => true,
                'message' => 'Registered device information retrieved',
                'data' => [
                    'registered_device_id' => $registeredDevice->device_id,
                    'first_login_time' => $registeredDevice->last_activity,
                    'ip_address' => $registeredDevice->ip_address,
                    'user_agent' => $registeredDevice->user_agent
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while retrieving registered device info',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Reset Device Binding API (Admin only - for testing/reset purposes)
     */
    public function resetDeviceBinding(Request $request)
    {
        try {
            $user = $request->user();
            
            // Remove all sessions for this user to reset device binding
            \DB::table('sessions')
                ->where('user_id', $user->id)
                ->delete();

            // Revoke all tokens
            // Simple token logout - just clear the session
            // In a real implementation, you would invalidate all tokens

            return response()->json([
                'success' => true,
                'message' => 'Device binding has been reset. You can now login from any device.',
                'data' => [
                    'user_id' => $user->id,
                    'reset_time' => time()
                ]
            ], 200);

        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'An error occurred while resetting device binding',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
