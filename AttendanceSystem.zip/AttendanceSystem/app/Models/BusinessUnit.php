<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class BusinessUnit extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'status',
        'timezone',
        'latitude',
        'longitude',
        'radius_meters',
    ];

    /**
     * Get the employees for the business unit.
     */
    public function employees(): HasMany
    {
        return $this->hasMany(EmployeeDetail::class, 'business_unit_id');
    }

    /**
     * Get the timezone label.
     */
    public function getTimezoneLabel(): string
    {
        $timezones = config('timezones');
        return $timezones[$this->timezone] ?? $this->timezone;
    }

    /**
     * Get the status label.
     */
    public function getStatusLabel(): string
    {
        return $this->status == 1 ? 'Active' : 'Inactive';
    }

    /**
     * Calculate distance between business unit and given coordinates using Haversine formula.
     * Returns distance in meters.
     */
    public function calculateDistanceTo($latitude, $longitude): float
    {
        if (!$this->latitude || !$this->longitude) {
            return PHP_FLOAT_MAX; // Return max distance if business unit location not set
        }

        $earthRadius = 6371000; // Earth's radius in meters

        $lat1 = deg2rad($this->latitude);
        $lon1 = deg2rad($this->longitude);
        $lat2 = deg2rad($latitude);
        $lon2 = deg2rad($longitude);

        $dlat = $lat2 - $lat1;
        $dlon = $lon2 - $lon1;

        $a = sin($dlat / 2) * sin($dlat / 2) +
             cos($lat1) * cos($lat2) *
             sin($dlon / 2) * sin($dlon / 2);

        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

        return $earthRadius * $c;
    }

    /**
     * Check if given coordinates are within the business unit's radius.
     */
    public function isWithinRadius($latitude, $longitude): bool
    {
        $distance = $this->calculateDistanceTo($latitude, $longitude);
        return $distance <= $this->radius_meters;
    }

    /**
     * Get formatted location string.
     */
    public function getLocationString(): string
    {
        if (!$this->latitude || !$this->longitude) {
            return 'Location not set';
        }
        
        return "Lat: {$this->latitude}, Lng: {$this->longitude} (Radius: {$this->radius_meters}m)";
    }
}
