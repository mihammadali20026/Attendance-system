<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;
use Carbon\Carbon;

class Attendance extends Model
{
    protected $fillable = [
        'user_id',
        'employee_detail_id',
        'attendance_date',
        'check_in_time',
        'check_out_time',
        'scheduled_check_in',
        'scheduled_check_out',
        'late_minutes',
        'early_departure_minutes',
        'total_working_minutes',
        'status',
        'notes',
        'check_in_location',
        'check_out_location',
        'device_id',
    ];

    protected $casts = [
        'attendance_date' => 'date',
        'check_in_time' => 'datetime:H:i:s',
        'check_out_time' => 'datetime:H:i:s',
        'scheduled_check_in' => 'datetime:H:i:s',
        'scheduled_check_out' => 'datetime:H:i:s',
    ];

    /**
     * Get the user that owns the attendance.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the employee detail that owns the attendance.
     */
    public function employeeDetail(): BelongsTo
    {
        return $this->belongsTo(EmployeeDetail::class);
    }

    /**
     * Get the media files associated with this attendance.
     */
    public function media(): MorphMany
    {
        return $this->morphMany(Media::class, 'parent');
    }

    /**
     * Get the status label.
     */
    public function getStatusLabel(): string
    {
        return match($this->status) {
            'present' => 'Present',
            'absent' => 'Absent',
            'late' => 'Late',
            'half_day' => 'Half Day',
            'overtime' => 'Overtime',
            default => 'Unknown'
        };
    }

    /**
     * Get the status badge class.
     */
    public function getStatusBadgeClass(): string
{
    return match($this->status) {
        'present' => 'bg-success text-white',
        'absent' => 'bg-danger text-white',
        'late' => 'bg-warning text-white',
        'half_day' => 'bg-info text-white',
        'overtime' => 'bg-primary text-white',
        default => 'bg-secondary text-white',
    };
}


    /**
     * Calculate late minutes using business unit timezone.
     */
    public function calculateLateMinutes(): int
    {
        if (!$this->check_in_time || !$this->scheduled_check_in) {
            return 0;
        }

        // Get business unit timezone
        $timezone = $this->employeeDetail->businessUnit->timezone ?? 'UTC';
        
        // Create Carbon instances in the business unit's timezone
        $checkIn = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->check_in_time->format('H:i:s'), $timezone);
        $scheduledCheckIn = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->scheduled_check_in->format('H:i:s'), $timezone);

        if ($checkIn->gt($scheduledCheckIn)) {
            return $checkIn->diffInMinutes($scheduledCheckIn);
        }

        return 0;
    }

    /**
     * Calculate early departure minutes using business unit timezone.
     */
    public function calculateEarlyDepartureMinutes(): int
    {
        if (!$this->check_out_time || !$this->scheduled_check_out) {
            return 0;
        }

        // Get business unit timezone
        $timezone = $this->employeeDetail->businessUnit->timezone ?? 'UTC';
        
        // Create Carbon instances in the business unit's timezone
        $checkOut = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->check_out_time->format('H:i:s'), $timezone);
        $scheduledCheckOut = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->scheduled_check_out->format('H:i:s'), $timezone);

        if ($checkOut->lt($scheduledCheckOut)) {
            return $scheduledCheckOut->diffInMinutes($checkOut);
        }

        return 0;
    }

    /**
     * Calculate total working minutes using business unit timezone.
     */
    public function calculateTotalWorkingMinutes(): int
    {
        if (!$this->check_in_time || !$this->check_out_time) {
            return 0;
        }

        // Get business unit timezone
        $timezone = $this->employeeDetail->businessUnit->timezone ?? 'UTC';
        
        // Create Carbon instances in the business unit's timezone
        $checkIn = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->check_in_time->format('H:i:s'), $timezone);
        $checkOut = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->check_out_time->format('H:i:s'), $timezone);

        // Ensure check-out is after check-in
        if ($checkOut->gt($checkIn)) {
            return $checkIn->diffInMinutes($checkOut);
        } else {
            return 0; // Invalid time range
        }
    }

    /**
     * Get formatted late time.
     */
    public function getFormattedLateTime(): string
    {
        if ($this->late_minutes <= 0) {
            return 'On Time';
        }

        $hours = intval($this->late_minutes / 60);
        $minutes = $this->late_minutes % 60;

        if ($hours > 0) {
            return "{$hours}h {$minutes}m late";
        }

        return "{$minutes}m late";
    }

    /**
     * Get formatted early departure time.
     */
    public function getFormattedEarlyDepartureTime(): string
    {
        if ($this->early_departure_minutes <= 0) {
            return 'On Time';
        }

        $hours = intval($this->early_departure_minutes / 60);
        $minutes = $this->early_departure_minutes % 60;

        if ($hours > 0) {
            return "{$hours}h {$minutes}m early";
        }

        return "{$minutes}m early";
    }

    /**
     * Get formatted working time.
     */
    public function getFormattedWorkingTime(): string
    {
        if ($this->total_working_minutes <= 0) {
            return 'N/A';
        }

        $hours = intval($this->total_working_minutes / 60);
        $minutes = $this->total_working_minutes % 60;

        return "{$hours}h {$minutes}m";
    }

    /**
     * Get timezone-aware check-in time.
     */
    public function getTimezoneAwareCheckInTime(): string
{
    if (!$this->check_in_time) {
        return 'N/A';
    }

    $timezone = $this->employeeDetail->businessUnit->timezone ?? 'UTC';
    $checkIn = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->check_in_time->format('H:i:s'), $timezone);
    
    return $checkIn->format('h:i A') . ' (' . $timezone . ')';
}

    /**
     * Get timezone-aware check-out time.
     */
    public function getTimezoneAwareCheckOutTime(): string
    {
        if (!$this->check_out_time) {
            return 'N/A';
        }

        $timezone = $this->employeeDetail->businessUnit->timezone ?? 'UTC';
        $checkOut = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->check_out_time->format('H:i:s'), $timezone);
        
        return $checkOut->format('h:i A') . ' (' . $timezone . ')';
    }

    /**
     * Get timezone-aware scheduled times.
     */
    public function getTimezoneAwareScheduledTimes(): string
    {
        if (!$this->scheduled_check_in || !$this->scheduled_check_out) {
            return 'Not Set';
        }

        $timezone = $this->employeeDetail->businessUnit->timezone ?? 'UTC';
        $scheduledIn = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->scheduled_check_in->format('H:i:s'), $timezone);
        $scheduledOut = Carbon::createFromFormat('Y-m-d H:i:s', $this->attendance_date->format('Y-m-d') . ' ' . $this->scheduled_check_out->format('H:i:s'), $timezone);
        
        return $scheduledIn->format('h:i A') . ' - ' . $scheduledOut->format('h:i A') . ' (' . $timezone . ')';
    }

    /**
     * Get business unit timezone.
     */
    public function getBusinessUnitTimezone(): string
    {
        return $this->employeeDetail->businessUnit->timezone ?? 'UTC';
    }
}
