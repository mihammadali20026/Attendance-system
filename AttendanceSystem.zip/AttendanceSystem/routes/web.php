<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\Auth\LoginController;
use App\Http\Controllers\Admin\Auth\ForgotPasswordController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\RoleController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\ScheduleController;
use App\Http\Controllers\Admin\BusinessUnitController;
use App\Http\Controllers\Admin\EmployeeController;
use App\Http\Controllers\Admin\AttendanceController;


    Route::get('/', [LoginController::class, 'showLoginForm'])->name('login');
    Route::post('login', [LoginController::class, 'login'])->name('login.submit');
    Route::get('forgot-password', [ForgotPasswordController::class, 'forgotPasswordForm'])->name('forgotPassword.form');
    Route::post('reset-password-link',[ForgotPasswordController::class,'resetPasswordLink'])->name('reset-password-link');
    Route::get('change-password/{id}',[ForgotPasswordController::class,'changePassword']);
    Route::post('reset-password',[ForgotPasswordController::class,'resetPassword'])->name('reset-password.update');

    Route::middleware(['auth'])->prefix('admin')->as('admin.')->group(function () {
        Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
        Route::get('logout', [DashboardController::class, 'logout'])->name('logout');

        Route::resource('schedules', ScheduleController::class);
        Route::resource('roles', RoleController::class);
        Route::resource('users', UserController::class);

        Route::resource('business-unit', BusinessUnitController::class);
        Route::resource('employees', EmployeeController::class);
        Route::resource('attendances', AttendanceController::class);
        Route::get('attendances-calendar', [AttendanceController::class, 'calendar'])->name('attendances.calendar');
        Route::get('attendances-calendar-data', [AttendanceController::class, 'getCalendarData'])->name('attendances.calendar.data');
        
        Route::get('profile', [ProfileController::class, 'index'])->name('profile');
        Route::put('profile/update', [ProfileController::class, 'updateProfile'])->name('profile.update');
        Route::put('profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password');


    });
