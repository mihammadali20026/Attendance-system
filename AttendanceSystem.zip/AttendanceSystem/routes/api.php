<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\AttendanceController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

// Authentication Routes
Route::prefix('auth')->group(function () {
    // Public routes (no authentication required)
    Route::post('login', [AuthController::class, 'login']);
    
    // Protected routes (authentication required)
    Route::middleware('auth:sanctum')->group(function () {
        Route::post('logout', [AuthController::class, 'logout']);
        Route::post('logout-all-devices', [AuthController::class, 'logoutAllDevices']);
        Route::get('profile', [AuthController::class, 'profile']);
        Route::post('revoke-all-tokens', [AuthController::class, 'revokeAllTokens']);
        Route::get('login-status', [AuthController::class, 'checkLoginStatus']);
        Route::get('registered-device', [AuthController::class, 'getRegisteredDevice']);
        Route::post('reset-device-binding', [AuthController::class, 'resetDeviceBinding']);
    });
});

// Attendance Routes
Route::prefix('attendance')->middleware('auth:sanctum')->group(function () {
    Route::post('check-in', [AttendanceController::class, 'checkIn']);
    Route::post('check-out', [AttendanceController::class, 'checkOut']);
    Route::get('today', [AttendanceController::class, 'getTodayAttendance']);
    Route::get('history', [AttendanceController::class, 'getAttendanceHistory']);
});

// Test route
Route::get('/test', function () {
    return response()->json([
        'message' => 'API is working!',
        'timestamp' => now()
    ]);
});
