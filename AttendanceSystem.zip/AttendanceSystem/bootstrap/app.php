<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'permission' => \Spatie\Permission\Middleware\PermissionMiddleware::class,
            'role' => \Spatie\Permission\Middleware\RoleMiddleware::class,
            'role_or_permission' => \Spatie\Permission\Middleware\RoleOrPermissionMiddleware::class,
            'api.token' => \App\Http\Middleware\ApiTokenAuth::class,
            'api.auth.handler' => \App\Http\Middleware\ApiAuthHandler::class,
        ]);
    })
    ->withExceptions(function (Exceptions $exceptions) {
        $exceptions->render(function (\Illuminate\Auth\AuthenticationException $e, $request) {
            if ($request->is('api/*')) {
                $token = $request->bearerToken();
                
                if (!$token) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Token not found',
                        'code' => 'TOKEN_NOT_FOUND'
                    ], 401);
                }

                return response()->json([
                    'success' => false,
                    'message' => 'Invalid or expired token',
                    'code' => 'TOKEN_INVALID'
                ], 401);
            }
        });
    })->create();
