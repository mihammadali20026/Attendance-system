<?php $__env->startSection('title', 'Attendance Management'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Attendance Management</h6>
            <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                <div>
                    <a href="<?php echo e(route('admin.attendances.create')); ?>" class="btn btn-primary text-white" title="Add Attendance">
                        <i class="fas fa-plus"></i> Add Attendance
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Total Records</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['total_records']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Present</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['present_count']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-check-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Late Arrivals</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['late_count']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clock fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-danger shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Absent</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($stats['absent_count']); ?></div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-times-circle fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="m-0 font-weight-bold text-primary">Filters</h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.attendances.index')); ?>">
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="start_date">Start Date</label>
                            <input type="date" name="start_date" id="start_date" class="form-control" 
                                   value="<?php echo e(request('start_date')); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="end_date">End Date</label>
                            <input type="date" name="end_date" id="end_date" class="form-control" 
                                   value="<?php echo e(request('end_date')); ?>">
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="employee_id">Employee</label>
                            <select name="employee_id" id="employee_id" class="form-control">
                                <option value="">All Employees</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>" 
                                        <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                        <?php echo e($employee->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control">
                                <option value="">All Status</option>
                                <option value="present" <?php echo e(request('status') == 'present' ? 'selected' : ''); ?>>Present</option>
                                <option value="late" <?php echo e(request('status') == 'late' ? 'selected' : ''); ?>>Late</option>
                                <option value="absent" <?php echo e(request('status') == 'absent' ? 'selected' : ''); ?>>Absent</option>
                                <option value="half_day" <?php echo e(request('status') == 'half_day' ? 'selected' : ''); ?>>Half Day</option>
                                <option value="overtime" <?php echo e(request('status') == 'overtime' ? 'selected' : ''); ?>>Overtime</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-3">
                        <div class="form-group">
                            <label for="business_unit_id">Business Unit</label>
                            <select name="business_unit_id" id="business_unit_id" class="form-control">
                                <option value="">All Business Units</option>
                                <?php $__currentLoopData = $businessUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($unit->id); ?>" 
                                        <?php echo e(request('business_unit_id') == $unit->id ? 'selected' : ''); ?>>
                                        <?php echo e($unit->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <div class="d-flex gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i> Filter
                                </button>
                                <a href="<?php echo e(route('admin.attendances.index')); ?>" class="btn btn-secondary">
                                    <i class="fas fa-times"></i> Clear
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Attendance Table -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Employee</th>
                            <th>Business Unit</th>
                            <th>Date</th>
                            <th>Check In</th>
                            <th>Check Out</th>
                            <th>Scheduled Time</th>
                            <th>Late Time</th>
                            <th>Working Time</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($attendances->firstItem() + $key); ?></td>
                            <td>
                                <div>
                                    <strong><?php echo e($attendance->user->name); ?></strong><br>
                                    <small class="text-muted"><?php echo e($attendance->user->email); ?></small>
                                </div>
                            </td>
                            <td><?php echo e($attendance->employeeDetail->businessUnit->name ?? 'N/A'); ?></td>
                            <td><?php echo e($attendance->attendance_date->format('d M, Y')); ?></td>
                            <td>
                                <?php if($attendance->check_in_time): ?>
                                    <span class="text-success"><?php echo e($attendance->getTimezoneAwareCheckInTime()); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($attendance->check_out_time): ?>
                                    <span class="text-danger"><?php echo e($attendance->getTimezoneAwareCheckOutTime()); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($attendance->scheduled_check_in && $attendance->scheduled_check_out): ?>
                                    <small><?php echo e($attendance->getTimezoneAwareScheduledTimes()); ?></small>
                                <?php else: ?>
                                    <span class="text-muted">Not Set</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($attendance->late_minutes > 0): ?>
                                    <span class="text-warning">
                                        <i class="fas fa-clock"></i> <?php echo e($attendance->getFormattedLateTime()); ?>

                                    </span>
                                <?php else: ?>
                                    <span class="text-success">On Time</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($attendance->total_working_minutes > 0): ?>
                                    <span class="text-info"><?php echo e($attendance->getFormattedWorkingTime()); ?></span>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge <?php echo e($attendance->getStatusBadgeClass()); ?> p-2">
                                    <?php echo e($attendance->getStatusLabel()); ?>

                                </span>
                            </td>
                            <td>
                                <div class="crud-icons d-flex align-items-center gap-3" style="gap:3px;">
                                    <div>
                                        <a href="<?php echo e(route('admin.attendances.show', $attendance->id)); ?>" 
                                           class="btn btn-primary btn-sm text-white" title="View">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </div>
                                    <div>
                                        <a href="<?php echo e(route('admin.attendances.edit', $attendance->id)); ?>" 
                                           class="btn btn-warning btn-sm text-white" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                    <div>
                                        <form action="<?php echo e(route('admin.attendances.destroy', $attendance->id)); ?>" 
                                              method="POST" style="display: inline;" 
                                              onsubmit="return confirm('Are you sure you want to delete this attendance record?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm text-white" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Pagination -->
            <div class="d-flex justify-content-center">
                <?php echo e($attendances->appends(request()->query())->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/attendances/index.blade.php ENDPATH**/ ?>