<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Create New Applicant -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-2 font-weight-bold text-primary">Users</h6>
            <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users-create')): ?>
                <div>
                    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary text-white" title="Add">
                        <i class="fas fa-plus"></i>
                    </a>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
    <!-- Data view for applicants -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive card-body">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Member Since</th>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['users-edit', 'users-delete'])): ?>
                            <th>Action</th>
                            <?php endif; ?>

                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e(++$key); ?></td>
                            <td><?php echo e($user->name); ?></td>
                            <td><?php echo e($user->email); ?></td>

                            <td>
                                <?php if(!empty($user->getRoleNames())): ?>
                                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="badge bg-success"><?php echo e($v); ?></label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($user->created_at->format('d M, Y')); ?></td>
                            <td>
                                <div
                                    class="crud-icons d-flex align-items-center justify-content-center gap-3  rounded p-2">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users-view')): ?>
                                    <div><a href="<?php echo e(route('admin.users.show', $user->id)); ?>"
                                            class="btn btn-primary text-white" title="view"><i
                                                class="fa fa-eye"></i></a>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users-edit')): ?>
                                    <div>
                                        <a href="<?php echo e(route('admin.users.edit', $user->id)); ?>"
                                            class="btn btn-warning mx-3 text-white" title="Edit"><i
                                                class="fas fa-edit"></i></a>
                                    </div>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users-delete')): ?>
                                    <div>
                                        <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST"
                                            style="display: inline;"
                                            onsubmit="return confirm('Are you sure you want to delete this user?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger text-white" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/users/index.blade.php ENDPATH**/ ?>