
<?php $__env->startSection('title', 'Edit Employee'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Edit Employee Form -->
        <div class="card mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Employee</h6>
            </div>
            <div class="card-body">
                <?php if($errors->any()): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('admin.employees.update', $employee->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    
                    <h5 class="mb-3 text-secondary">User Information</h5>
                    <div class="row">
                        <!-- Name -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Enter Full Name" value="<?php echo e(old('name', $employee->user->name)); ?>" required>
                            </div>
                        </div>

                        <!-- Email -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control" id="email" placeholder="Enter Email" value="<?php echo e(old('email', $employee->user->email)); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password">Password <small class="text-muted">(Leave blank to keep current)</small></label>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Enter New Password">
                            </div>
                        </div>

                        <!-- Confirm Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password_confirmation">Confirm Password</label>
                                <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" placeholder="Confirm Password">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Status -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="status">Status <span class="text-danger">*</span></label>
                                <select name="status" id="status" class="form-control select2">
                                    <option value="1" <?php echo e(old('status', $employee->user->status) == '1' ? 'selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e(old('status', $employee->user->status) == '0' ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <h5 class="mb-3 text-secondary">Employee Details</h5>
                    <div class="row">
                        <!-- Business Unit -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="business_unit_id">Business Unit <span class="text-danger">*</span></label>
                                <select name="business_unit_id" id="business_unit_id" class="form-control select2" required>
                                    <option value="">Select Business Unit</option>
                                    <?php $__currentLoopData = $businessUnits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $businessUnit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($businessUnit->id); ?>" <?php echo e(old('business_unit_id', $employee->business_unit_id) == $businessUnit->id ? 'selected' : ''); ?>>
                                            <?php echo e($businessUnit->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <!-- Position -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="position">Position <span class="text-danger">*</span></label>
                                <input type="text" name="position" class="form-control" id="position" placeholder="e.g., Manager, Developer" value="<?php echo e(old('position', $employee->position)); ?>" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Schedule -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="schedule_id">Schedule</label>
                                <select name="schedule_id" id="schedule_id" class="form-control select2">
                                    <option value="">Select Schedule (Optional)</option>
                                    <?php $__currentLoopData = $schedules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $schedule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($schedule->id); ?>" <?php echo e(old('schedule_id', $employee->schedule_id) == $schedule->id ? 'selected' : ''); ?>>
                                            <?php echo e($schedule->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <!-- Work Type -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="work_type">Work Type <span class="text-danger">*</span></label>
                                <select name="work_type" id="work_type" class="form-control select2" required>
                                    <option value="">Select Work Type</option>
                                    <option value="0" <?php echo e(old('work_type', $employee->work_type) == '0' ? 'selected' : ''); ?>>Inside</option>
                                    <option value="1" <?php echo e(old('work_type', $employee->work_type) == '1' ? 'selected' : ''); ?>>Outside</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mt-3">Update</button>
                    <a href="<?php echo e(route('admin.employees.index')); ?>" class="btn btn-secondary mt-3">Cancel</a>
                </form>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/employees/edit.blade.php ENDPATH**/ ?>