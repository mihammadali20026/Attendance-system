<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('admin.dashboard')); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <!-- <i class="fas fa-laugh-wink"></i> -->
        </div>
        <!-- <div class="sidebar-brand-text mx-3">Nixxe Solutions</div> -->
        <img src="<?php echo e(asset('assets/admin/img/logo.png')); ?>" alt="Logo" height="40">

    </a>

    <!-- Divider -->
    <hr class="sidebar-divider my-0" />

    <!-- Nav Item - Dashboard -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.dashboard') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider" />

    <!-- Company Management Section -->
    <div class="sidebar-heading">Company Management</div>
    
    <!-- Business Unit -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.business-unit.*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.business-unit.index')); ?>">
            <i class="fas fa-fw fa-building"></i>
            <span>Business Units</span>
        </a>
    </li>

    <!-- Schedule -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.schedules.*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.schedules.index')); ?>">
            <i class="fas fa-fw fa-calendar-alt"></i>
            <span>Schedules</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider" />

    <!-- User Management Section -->
    <div class="sidebar-heading">User Management</div>
    
    <!-- Users -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.users.*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.users.index')); ?>">
            <i class="fas fa-fw fa-users"></i>
            <span>Users</span>
        </a>
    </li>

    <!-- Employees -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.employees.*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.employees.index')); ?>">
            <i class="fas fa-fw fa-user-tie"></i>
            <span>Employees</span>
        </a>
    </li>

    <!-- Roles -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.roles.*') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.roles.index')); ?>">
            <i class="fas fa-fw fa-user-shield"></i>
            <span>Roles & Permissions</span>
        </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider" />

    <!-- Attendance Management Section -->
    <div class="sidebar-heading">Attendance Management</div>
    
    <!-- Attendance List -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.attendances.index') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.attendances.index')); ?>">
            <i class="fas fa-fw fa-clock"></i>
            <span>Attendance Records</span>
        </a>
    </li>

    <!-- Attendance Calendar -->
    <li class="nav-item <?php echo e(request()->routeIs('admin.attendances.calendar') ? 'active' : ''); ?>">
        <a class="nav-link" href="<?php echo e(route('admin.attendances.calendar')); ?>">
            <i class="fas fa-fw fa-calendar-check"></i>
            <span>Attendance Calendar</span>
        </a>
    </li>

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>
</ul>
<!-- End of Sidebar --><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/components/sidebar.blade.php ENDPATH**/ ?>