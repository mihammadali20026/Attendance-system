<?php $__env->startSection('title', 'Business Unit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Create New Applicant -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex align-items-center justify-content-between">
                <h6 class="m-2 font-weight-bold text-primary">Business Unit</h6>
                <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                    <div>
                        <a href="<?php echo e(route('admin.business-unit.create')); ?>" class="btn btn-primary text-white" title="Add Business Unit">
                            <i class="fas fa-plus"></i> Add Business Unit
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Data view for applicants -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Business Unit Name</th>
                                <th>Timezone</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Employees Count</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($unit->name); ?></td>
                                    <td>
                                        <span class="badge bg-info"><?php echo e($unit->getTimezoneLabel()); ?></span>
                                    </td>
                                    <td>
                                        <?php if($unit->latitude && $unit->longitude): ?>
                                            <div class="text-sm">
                                                <i class="fas fa-map-marker-alt text-primary"></i>
                                                <span class="text-muted"><?php echo e(number_format($unit->latitude, 6)); ?>, <?php echo e(number_format($unit->longitude, 6)); ?></span>
                                                <br>
                                                <small class="text-success">Radius: <?php echo e($unit->radius_meters); ?>m</small>
                                            </div>
                                        <?php else: ?>
                                            <span class="text-muted">Not Set</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php if($unit->status == 1): ?>
                                            <span class="badge bg-success">Active</span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">Inactive</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="badge bg-primary"><?php echo e($unit->employees->count()); ?> Employee(s)</span>
                                    </td>
                                    <td><?php echo e($unit->created_at->format('d M, Y')); ?></td>
                                    <td>
                                        <div class="crud-icons d-flex align-items-center justify-content-center gap-3 rounded p-2">
                                            <div>
                                                <a href="<?php echo e(route('admin.business-unit.show', $unit->id)); ?>" class="btn btn-primary text-white" title="View">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </div>
                                            <div>
                                                <a href="<?php echo e(route('admin.business-unit.edit', $unit->id)); ?>" class="btn btn-warning mx-3 text-white" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                            <div>
                                                <form action="<?php echo e(route('admin.business-unit.destroy', $unit->id)); ?>" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this business unit?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger text-white" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/businessUnit/index.blade.php ENDPATH**/ ?>