
<?php $__env->startSection('title', 'View Attendance'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- View Attendance Details -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Attendance Details</h6>
            <div>
                <a href="<?php echo e(route('admin.attendances.edit', $attendance->id)); ?>" class="btn btn-warning text-white">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="<?php echo e(route('admin.attendances.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- Employee Information -->
                <div class="col-md-6">
                    <h5 class="mb-3 text-secondary border-bottom pb-2">Employee Information</h5>
                    <div class="form-group">
                        <label><strong>Employee Name</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->user->name); ?></p>
                    </div>
                    <div class="form-group">
                        <label><strong>Email</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->user->email); ?></p>
                    </div>
                    <div class="form-group">
                        <label><strong>Business Unit</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->employeeDetail->businessUnit->name ?? 'N/A'); ?></p>
                    </div>
                    <div class="form-group">
                        <label><strong>Timezone</strong></label>
                        <p class="form-control-plaintext">
                            <span class="badge bg-info"><?php echo e($attendance->getBusinessUnitTimezone()); ?></span>
                        </p>
                    </div>
                    <div class="form-group">
                        <label><strong>Position</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->employeeDetail->position ?? 'N/A'); ?></p>
                    </div>
                </div>

                <!-- Attendance Information -->
                <div class="col-md-6">
                    <h5 class="mb-3 text-secondary border-bottom pb-2">Attendance Information</h5>
                    <div class="form-group">
                        <label><strong>Attendance Date</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->attendance_date->format('d M, Y')); ?></p>
                    </div>
                    <div class="form-group">
                        <label><strong>Status</strong></label>
                        <div class="mt-2">
                            <span class="badge <?php echo e($attendance->getStatusBadgeClass()); ?> p-2">
                                <?php echo e($attendance->getStatusLabel()); ?>

                            </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label><strong>Device ID</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->device_id ?? 'N/A'); ?></p>
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <!-- Time Information -->
            <h5 class="mb-3 text-secondary border-bottom pb-2">Time Information</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Check In Time</strong></label>
                        <p class="form-control-plaintext">
                            <?php if($attendance->check_in_time): ?>
                                <span class="text-success"><?php echo e($attendance->getTimezoneAwareCheckInTime()); ?></span>
                            <?php else: ?>
                                <span class="text-muted">Not checked in</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="form-group">
                        <label><strong>Check Out Time</strong></label>
                        <p class="form-control-plaintext">
                            <?php if($attendance->check_out_time): ?>
                                <span class="text-danger"><?php echo e($attendance->getTimezoneAwareCheckOutTime()); ?></span>
                            <?php else: ?>
                                <span class="text-muted">Not checked out</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Scheduled Time</strong></label>
                        <p class="form-control-plaintext">
                            <?php if($attendance->scheduled_check_in && $attendance->scheduled_check_out): ?>
                                <?php echo e($attendance->getTimezoneAwareScheduledTimes()); ?>

                            <?php else: ?>
                                <span class="text-muted">Not set</span>
                            <?php endif; ?>
                        </p>
                    </div>
                    <div class="form-group">
                        <label><strong>Working Time</strong></label>
                        <p class="form-control-plaintext">
                            <?php if($attendance->total_working_minutes > 0): ?>
                                <span class="text-info"><?php echo e($attendance->getFormattedWorkingTime()); ?></span>
                            <?php else: ?>
                                <span class="text-muted">N/A</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <!-- Late/Early Information -->
            <h5 class="mb-3 text-secondary border-bottom pb-2">Late/Early Information</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Late Arrival</strong></label>
                        <p class="form-control-plaintext">
                            <?php if($attendance->late_minutes > 0): ?>
                                <span class="text-warning">
                                    <i class="fas fa-clock"></i> <?php echo e($attendance->getFormattedLateTime()); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-success">On Time</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Early Departure</strong></label>
                        <p class="form-control-plaintext">
                            <?php if($attendance->early_departure_minutes > 0): ?>
                                <span class="text-info">
                                    <i class="fas fa-clock"></i> <?php echo e($attendance->getFormattedEarlyDepartureTime()); ?>

                                </span>
                            <?php else: ?>
                                <span class="text-success">On Time</span>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>
            </div>

            <!-- Location Information -->
            <?php if($attendance->check_in_location || $attendance->check_out_location): ?>
            <hr class="my-4">
            <h5 class="mb-3 text-secondary border-bottom pb-2">Location Information</h5>
            <div class="row">
                <?php if($attendance->check_in_location): ?>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Check In Location</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->check_in_location); ?></p>
                    </div>
                </div>
                <?php endif; ?>
                <?php if($attendance->check_out_location): ?>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Check Out Location</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->check_out_location); ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Notes -->
            <?php if($attendance->notes): ?>
            <hr class="my-4">
            <h5 class="mb-3 text-secondary border-bottom pb-2">Notes</h5>
            <div class="form-group">
                <p class="form-control-plaintext"><?php echo e($attendance->notes); ?></p>
            </div>
            <?php endif; ?>

            <!-- Additional Information -->
            <hr class="my-4">
            <h5 class="mb-3 text-secondary border-bottom pb-2">Additional Information</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Created At</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->created_at->format('d M, Y h:i A')); ?></p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Last Updated</strong></label>
                        <p class="form-control-plaintext"><?php echo e($attendance->updated_at->format('d M, Y h:i A')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/attendances/view.blade.php ENDPATH**/ ?>