
<?php $__env->startSection('title', 'Business Unit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- Create New Applicant -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex align-items-center justify-content-between">
                <h6 class="m-2 font-weight-bold text-primary">Business Unit</h6>
                <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users-create')): ?>
                        <div>
                            <button type="button" class="btn btn-primary text-white" title="Add" data-toggle="modal"
                                data-target="#addScheduleModal">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>
        <!-- Data view for applicants -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($unit->name); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($unit->time_in)->format('h:i A')); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($unit->time_out)->format('h:i A')); ?></td>

                                    <td>
                                        <div
                                            class="crud-icons d-flex align-items-center justify-content-center gap-3  rounded p-2">
                                            <div>
                                                <a href="#" id="editButton<?php echo e($unit->id); ?>"
                                                    data-toggle="modal"
                                                    data-target="#editScheduleModal"
                                                    data-id="<?php echo e($unit->id); ?>"
                                                    data-name="<?php echo e($unit->name); ?>"
                                                    data-time-in="<?php echo e($unit->time_in); ?>"
                                                    data-time-out="<?php echo e($unit->time_out); ?>"
                                                    class="btn btn-warning mx-3 text-white" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                            
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('admin.schedule.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.schedule.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    // When any edit button is clicked
    $('a[id^="editButton"]').on('click', function() {
        // Get the data attributes from the clicked button
        var id = $(this).data('id');
        var name = $(this).data('name');
        var timeIn = $(this).data('time-in');
        var timeOut = $(this).data('time-out');

        // Populate the modal fields with the values
        $('#editScheduleModal').find('#name').val(name);
        $('#editScheduleModal').find('#time_in').val(timeIn.substring(0, 5));
        $('#editScheduleModal').find('#time_out').val(timeOut.substring(0, 5));

        $('#editScheduleForm').attr('action', '/admin/schedules/' + id);
    });
});
</script>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/schedule/index.blade.php ENDPATH**/ ?>