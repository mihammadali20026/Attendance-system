
<?php $__env->startSection('title', 'View Business Unit'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- View Business Unit Details -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">View Business Unit Details</h6>
                <div>
                    <a href="<?php echo e(route('admin.business-unit.edit', $businessUnit->id)); ?>" class="btn btn-warning text-white">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="<?php echo e(route('admin.business-unit.index')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                </div>
            </div>
            <div class="card-body">
                <h5 class="mb-3 text-secondary border-bottom pb-2">Business Unit Information</h5>
                <div class="row">
                    <!-- Business Unit Name -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name"><strong>Business Unit Name</strong></label>
                            <input type="text" class="form-control" value="<?php echo e($businessUnit->name); ?>" disabled readonly>
                        </div>
                    </div>

                    <!-- Timezone -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="timezone"><strong>Timezone</strong></label>
                            <input type="text" class="form-control" value="<?php echo e($businessUnit->getTimezoneLabel()); ?>" disabled readonly>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Status -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status"><strong>Status</strong></label>
                            <div class="mt-2">
                                <?php if($businessUnit->status == 1): ?>
                                    <span class="badge bg-success p-2">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-danger p-2">Inactive</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Employee Count -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="employee_count"><strong>Total Employees</strong></label>
                            <div class="mt-2">
                                <span class="badge bg-primary p-2"><?php echo e($businessUnit->employees->count()); ?> Employee(s)</span>
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="my-4">

                <h5 class="mb-3 text-secondary border-bottom pb-2">Location Information</h5>
                <div class="row">
                    <!-- Location Coordinates -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="location"><strong>Coordinates</strong></label>
                            <?php if($businessUnit->latitude && $businessUnit->longitude): ?>
                                <div class="mt-2">
                                    <i class="fas fa-map-marker-alt text-primary"></i>
                                    <span class="text-muted"><?php echo e(number_format($businessUnit->latitude, 6)); ?>, <?php echo e(number_format($businessUnit->longitude, 6)); ?></span>
                                </div>
                            <?php else: ?>
                                <div class="mt-2">
                                    <span class="text-muted">Location not set</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Check-in Radius -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="radius"><strong>Check-in Radius</strong></label>
                            <div class="mt-2">
                                <?php if($businessUnit->radius_meters): ?>
                                    <span class="badge bg-info p-2"><?php echo e($businessUnit->radius_meters); ?> meters</span>
                                <?php else: ?>
                                    <span class="text-muted">Not set</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <?php if($businessUnit->latitude && $businessUnit->longitude): ?>
                <div class="row">
                    <div class="col-12">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>Location Details:</strong> 
                            Employees assigned to this business unit can only check in when they are within 
                            <strong><?php echo e($businessUnit->radius_meters); ?> meters</strong> of the specified coordinates.
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <hr class="my-4">

                <h5 class="mb-3 text-secondary border-bottom pb-2">Additional Information</h5>
                <div class="row">
                    <!-- Created At -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="created_at"><strong>Created At</strong></label>
                            <input type="text" class="form-control" value="<?php echo e($businessUnit->created_at->format('d M, Y h:i A')); ?>" disabled readonly>
                        </div>
                    </div>

                    <!-- Updated At -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="updated_at"><strong>Last Updated</strong></label>
                            <input type="text" class="form-control" value="<?php echo e($businessUnit->updated_at->format('d M, Y h:i A')); ?>" disabled readonly>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/businessUnit/view.blade.php ENDPATH**/ ?>