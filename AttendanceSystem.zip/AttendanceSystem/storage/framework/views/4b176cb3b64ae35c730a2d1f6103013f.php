
<?php $__env->startSection('title', 'Employee Attendance Calendar'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Page Header -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-calendar-alt"></i> Employee Attendance Calendar
            </h6>
            <div class="d-flex gap-2">
                <a href="<?php echo e(route('admin.attendances.index')); ?>" class="btn btn-secondary">
                    <i class="fas fa-list"></i> Back to List
                </a>
                <button class="btn btn-info" onclick="exportCalendar()">
                    <i class="fas fa-download"></i> Export
                </button>
            </div>
        </div>
    </div>

    <!-- Employee Selection -->
    <div class="card mb-4">
        <div class="card-header">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-user"></i> Select Employee
            </h6>
        </div>
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('admin.attendances.calendar')); ?>" id="employeeForm">
                <div class="row">
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="employee_id">Select Employee</label>
                            <select name="employee_id" id="employee_id" class="form-control" required>
                                <option value="">Choose an employee...</option>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($employee->id); ?>" 
                                        <?php echo e(request('employee_id') == $employee->id ? 'selected' : ''); ?>>
                                        <?php echo e($employee->name); ?> - <?php echo e($employee->employeeDetail->businessUnit->name ?? 'N/A'); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="month_filter">Filter by Month</label>
                            <input type="month" name="month_filter" id="month_filter" class="form-control" 
                                   value="<?php echo e(request('month_filter', date('Y-m'))); ?>">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-search"></i> Load Calendar
                                </button>
                                <button type="button" class="btn btn-secondary" onclick="resetCalendar()">
                                    <i class="fas fa-refresh"></i> Reset
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <?php if($selectedEmployee): ?>
    <!-- Employee Information -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row">
                <div class="col-md-2">
                    <div class="text-center">
                        <div class="avatar-circle bg-primary text-white">
                            <?php echo e(substr($selectedEmployee->name, 0, 1)); ?>

                        </div>
                    </div>
                </div>
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-md-3">
                            <strong>Employee:</strong><br>
                            <span class="text-primary"><?php echo e($selectedEmployee->name); ?></span>
                        </div>
                        <div class="col-md-3">
                            <strong>Email:</strong><br>
                            <span class="text-muted"><?php echo e($selectedEmployee->email); ?></span>
                        </div>
                        <div class="col-md-3">
                            <strong>Business Unit:</strong><br>
                            <span class="badge bg-info"><?php echo e($selectedEmployee->employeeDetail->businessUnit->name ?? 'N/A'); ?></span>
                        </div>
                        <div class="col-md-3">
                            <strong>Timezone:</strong><br>
                            <span class="badge bg-secondary text-white"><?php echo e($selectedEmployee->employeeDetail->businessUnit->timezone ?? 'UTC'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Statistics Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0" id="presentCount">0</h4>
                            <small>Present Days</small>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-check-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0" id="lateCount">0</h4>
                            <small>Late Days</small>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-clock fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0" id="absentCount">0</h4>
                            <small>Absent Days</small>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-times-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-info text-white">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div>
                            <h4 class="mb-0" id="overtimeCount">0</h4>
                            <small>Overtime Days</small>
                        </div>
                        <div class="align-self-center">
                            <i class="fas fa-plus-circle fa-2x"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Calendar Legend -->
    <div class="card mb-4">
        <div class="card-body">
            <h6 class="font-weight-bold mb-3">
                <i class="fas fa-info-circle"></i> Legend & Status
            </h6>
            <div class="row">
                <div class="col-md-2">
                    <div class="d-flex align-items-center mb-2">
                        <div class="legend-color" style="width: 20px; height: 20px; background-color: #28a745; margin-right: 10px; border-radius: 3px;"></div>
                        <span>Present</span>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="d-flex align-items-center mb-2">
                        <div class="legend-color" style="width: 20px; height: 20px; background-color: #ffc107; margin-right: 10px; border-radius: 3px;"></div>
                        <span>Late</span>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="d-flex align-items-center mb-2">
                        <div class="legend-color" style="width: 20px; height: 20px; background-color: #dc3545; margin-right: 10px; border-radius: 3px;"></div>
                        <span>Absent</span>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="d-flex align-items-center mb-2">
                        <div class="legend-color" style="width: 20px; height: 20px; background-color: #17a2b8; margin-right: 10px; border-radius: 3px;"></div>
                        <span>Half Day</span>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="d-flex align-items-center mb-2">
                        <div class="legend-color" style="width: 20px; height: 20px; background-color: #007bff; margin-right: 10px; border-radius: 3px;"></div>
                        <span>Overtime</span>
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="d-flex align-items-center mb-2">
                        <i class="fas fa-mouse-pointer text-info mr-2"></i>
                        <span>Click for details</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- Calendar -->
    <div class="card">
        <div class="card-body">
            <div id="calendar"></div>
        </div>
    </div>
</div>

<!-- Event Details Modal -->
<div class="modal fade" id="eventModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <i class="fas fa-calendar-day"></i> Attendance Details
                </h5>
                <button type="button" class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <div class="modal-body" id="eventModalBody">
                <!-- Event details will be loaded here -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<!-- Select2 CSS -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

<!-- FullCalendar CSS -->
<link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.css" rel="stylesheet">

<!-- Select2 JS -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<!-- FullCalendar JS -->
<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.11.5/main.min.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing advanced calendar...');
    
    // Initialize Select2 on employee dropdown
    $('#employee_id').select2({
        placeholder: 'Choose an employee...',
        allowClear: true,
        width: '100%',
        language: {
            noResults: function() {
                return "No employees found";
            },
            searching: function() {
                return "Searching...";
            }
        }
    });
    
    var calendarEl = document.getElementById('calendar');
    if (!calendarEl) {
        console.error('Calendar element not found!');
        return;
    }
    
    var selectedEmployeeId = '<?php echo e(request("employee_id")); ?>';
    var selectedMonth = '<?php echo e(request("month_filter", date("Y-m"))); ?>';
    
    console.log('Selected employee ID:', selectedEmployeeId);
    console.log('Selected month:', selectedMonth);
    
    if (!selectedEmployeeId) {
        calendarEl.innerHTML = '<div class="text-center p-5"><h5><i class="fas fa-user-slash"></i> Please select an employee to view their attendance calendar</h5></div>';
        return;
    }
    
    // Check if FullCalendar is loaded
    if (typeof FullCalendar === 'undefined') {
        console.error('FullCalendar is not loaded!');
        calendarEl.innerHTML = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> FullCalendar library not loaded. Please refresh the page.</div>';
        return;
    }
    
    console.log('FullCalendar loaded, creating advanced calendar...');
    
    try {
        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay,listWeek'
            },
            height: 'auto',
            firstDay: 1, // Start week on Monday
            dayMaxEvents: 4,
            moreLinkClick: 'popover',
            eventDisplay: 'block',
            eventTimeFormat: {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            },
            events: function(info, successCallback, failureCallback) {
                console.log('Loading calendar events for employee:', selectedEmployeeId);
                console.log('Date range:', info.startStr, 'to', info.endStr);
                
                // Convert ISO datetime to simple date format (Y-m-d)
                var startDate = info.start.toISOString().split('T')[0];
                var endDate = info.end.toISOString().split('T')[0];
                
                var url = '<?php echo e(route("admin.attendances.calendar.data")); ?>?employee_id=' + selectedEmployeeId +
                          '&start_date=' + startDate + '&end_date=' + endDate;
                console.log('Request URL:', url);
                console.log('Parameters being sent:', {
                    employee_id: selectedEmployeeId,
                    start_date: startDate,
                    end_date: endDate,
                    original_start: info.startStr,
                    original_end: info.endStr
                });

                fetch(url, {
                    method: 'GET',
                    headers: {
                        'Accept': 'application/json',
                        'X-Requested-With': 'XMLHttpRequest'
                    },
                    credentials: 'same-origin'
                })
                    .then(async (response) => {
                        console.log('Response status:', response.status);
                        const contentType = response.headers.get('content-type') || '';
                        const bodyText = await response.text();

                        if (!response.ok) {
                            console.error('Non-200 response body:', bodyText);
                            throw new Error('HTTP error! status: ' + response.status);
                        }

                        if (!contentType.includes('application/json')) {
                            console.error('Non-JSON response body:', bodyText);
                            throw new Error('Non-JSON response received (content-type: ' + contentType + ')');
                        }

                        try {
                            return JSON.parse(bodyText);
                        } catch (e) {
                            console.error('Failed to parse JSON:', bodyText);
                            throw e;
                        }
                    })
                    .then((data) => {
                        console.log('Calendar data received:', data);
                        updateStatistics(data);
                        successCallback(data);
                    })
                    .catch((error) => {
                        console.error('Error loading calendar data:', error);
                        // Show a friendly message in the UI so user knows what happened
                        const errorBox = document.createElement('div');
                        errorBox.className = 'alert alert-warning';
                        errorBox.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Failed to load calendar data: ' + error.message + '. Check console for details.';
                        calendarEl.parentElement.insertBefore(errorBox, calendarEl);
                        failureCallback(error);
                    });
            },
            eventClick: function(info) {
                var event = info.event;
                var props = event.extendedProps;
                
                var modalContent = '<div class="row">';
                modalContent += '<div class="col-md-6">';
                modalContent += '<h6><i class="fas fa-calendar"></i> Date Information</h6>';
                modalContent += '<p><strong>Date:</strong> ' + event.start.toLocaleDateString() + '</p>';
                modalContent += '<p><strong>Status:</strong> <span class="badge badge-' + getStatusClass(props.status) + '">' + formatStatus(props.status) + '</span></p>';
                modalContent += '<p><strong>Timezone:</strong> ' + (props.timezone || 'UTC') + '</p>';
                modalContent += '</div>';
                
                modalContent += '<div class="col-md-6">';
                modalContent += '<h6><i class="fas fa-clock"></i> Time Information</h6>';
                modalContent += '<p><strong>Check In:</strong> ' + (props.check_in_time || 'N/A') + '</p>';
                modalContent += '<p><strong>Check Out:</strong> ' + (props.check_out_time || 'N/A') + '</p>';
                modalContent += '<p><strong>Working Time:</strong> ' + (props.formatted_working_time || 'N/A') + '</p>';
                modalContent += '</div>';
                modalContent += '</div>';
                
                if (props.late_minutes > 0 || props.early_departure_minutes > 0) {
                    modalContent += '<hr><div class="row">';
                    modalContent += '<div class="col-md-6">';
                    if (props.late_minutes > 0) {
                        modalContent += '<p><strong>Late by:</strong> <span class="text-warning">' + formatMinutesToHours(props.late_minutes) + '</span></p>';
                    }
                    if (props.early_departure_minutes > 0) {
                        modalContent += '<p><strong>Early by:</strong> <span class="text-info">' + formatMinutesToHours(props.early_departure_minutes) + '</span></p>';
                    }
                    modalContent += '</div>';
                    modalContent += '</div>';
                }
                
                if (props.notes) {
                    modalContent += '<hr><div class="row">';
                    modalContent += '<div class="col-12">';
                    modalContent += '<h6><i class="fas fa-sticky-note"></i> Notes</h6>';
                    modalContent += '<p>' + props.notes + '</p>';
                    modalContent += '</div>';
                    modalContent += '</div>';
                }
                
                document.getElementById('eventModalBody').innerHTML = modalContent;
                $('#eventModal').modal('show');
            },
            eventDidMount: function(info) {
                info.el.title = info.event.title;
                info.el.style.cursor = 'pointer';
            },
            dateClick: function(info) {
                console.log('Date clicked:', info.dateStr);
            },
            viewDidMount: function(info) {
                console.log('View mounted:', info.view.type);
            }
        });
        
        calendar.render();
        console.log('Advanced calendar rendered successfully!');
        
        // Set initial date if month filter is provided
        if (selectedMonth) {
            var date = new Date(selectedMonth + '-01');
            calendar.gotoDate(date);
        }
        
    } catch (error) {
        console.error('Error initializing calendar:', error);
        calendarEl.innerHTML = '<div class="alert alert-danger"><i class="fas fa-exclamation-triangle"></i> Error loading calendar: ' + error.message + '</div>';
    }
});

// Helper functions
function formatStatus(status) {
    if (!status) return 'N/A';
    return status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, ' ');
}

function formatMinutesToHours(minutes) {
    if (!minutes || minutes <= 0) return '0m';
    
    var hours = Math.floor(minutes / 60);
    var remainingMinutes = minutes % 60;
    
    if (hours > 0 && remainingMinutes > 0) {
        return hours + 'h ' + remainingMinutes + 'm';
    } else if (hours > 0) {
        return hours + 'h';
    } else {
        return remainingMinutes + 'm';
    }
}

function getStatusClass(status) {
    switch(status) {
        case 'present': return 'success';
        case 'late': return 'warning';
        case 'absent': return 'danger';
        case 'half_day': return 'info';
        case 'overtime': return 'primary';
        default: return 'secondary';
    }
}

function updateStatistics(events) {
    var presentCount = 0;
    var lateCount = 0;
    var absentCount = 0;
    var overtimeCount = 0;
    
    events.forEach(function(event) {
        var status = event.extendedProps.status;
        switch(status) {
            case 'present':
                presentCount++;
                break;
            case 'late':
                lateCount++;
                break;
            case 'absent':
                absentCount++;
                break;
            case 'overtime':
                overtimeCount++;
                break;
        }
    });
    
    document.getElementById('presentCount').textContent = presentCount;
    document.getElementById('lateCount').textContent = lateCount;
    document.getElementById('absentCount').textContent = absentCount;
    document.getElementById('overtimeCount').textContent = overtimeCount;
}

function resetCalendar() {
    document.getElementById('employee_id').value = '';
    document.getElementById('month_filter').value = '';
    window.location.href = '<?php echo e(route("admin.attendances.calendar")); ?>';
}

function exportCalendar() {
    var employeeId = document.getElementById('employee_id').value;
    if (!employeeId) {
        alert('Please select an employee first.');
        return;
    }
    
    var month = document.getElementById('month_filter').value;
    var url = '<?php echo e(route("admin.attendances.calendar")); ?>?employee_id=' + employeeId + '&month_filter=' + month + '&export=1';
    window.open(url, '_blank');
}
</script>

<style>
.avatar-circle {
    width: 60px;
    height: 60px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 24px;
    font-weight: bold;
    margin: 0 auto;
}

.legend-color {
    border: 1px solid #ddd;
}

.fc-event {
    border-radius: 4px;
    font-size: 0.85em;
    padding: 2px 4px;
    cursor: pointer;
}

.fc-event-title {
    font-weight: 500;
}

.fc-daygrid-event {
    margin: 1px 2px;
}

.fc-timegrid-event {
    margin: 1px 0;
}

.fc-event-main {
    padding: 2px 4px;
}

.fc-toolbar-title {
    font-size: 1.5em;
    font-weight: 600;
}

.fc-button {
    border-radius: 4px;
}

.fc-button-primary {
    background-color: #007bff;
    border-color: #007bff;
}

.fc-button-primary:hover {
    background-color: #0056b3;
    border-color: #0056b3;
}

.fc-button-primary:focus {
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25);
}

.fc-daygrid-day-number {
    font-weight: 500;
}

.fc-day-today {
    background-color: rgba(0, 123, 255, 0.1);
}

/* Custom styles for different event types */
.fc-event[data-event-type="checkin"] {
    border-left: 4px solid #28a745;
}

.fc-event[data-event-type="checkout"] {
    border-left: 4px solid #dc3545;
}

.fc-event[data-event-type="working"] {
    border-left: 4px solid #6c757d;
}

/* Statistics cards */
.card.bg-success, .card.bg-warning, .card.bg-danger, .card.bg-info {
    border: none;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.card.bg-success:hover, .card.bg-warning:hover, .card.bg-danger:hover, .card.bg-info:hover {
    transform: translateY(-2px);
    transition: transform 0.2s;
}

/* Select2 Custom Styling */
.select2-container--default .select2-selection--single {
    height: 38px !important;
    border: 1px solid #ced4da !important;
    border-radius: 0.375rem !important;
    padding: 0.375rem 0.75rem !important;
}

.select2-container--default .select2-selection--single .select2-selection__rendered {
    line-height: 26px !important;
    padding-left: 0 !important;
    padding-right: 20px !important;
}

.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 36px !important;
    right: 8px !important;
}

.select2-container--default .select2-selection--single:focus {
    border-color: #80bdff !important;
    box-shadow: 0 0 0 0.2rem rgba(0, 123, 255, 0.25) !important;
}

.select2-dropdown {
    border: 1px solid #ced4da !important;
    border-radius: 0.375rem !important;
    box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075) !important;
}

.select2-container--default .select2-search--dropdown .select2-search__field {
    border: 1px solid #ced4da !important;
    border-radius: 0.25rem !important;
    padding: 0.375rem 0.75rem !important;
}

.select2-container--default .select2-results__option--highlighted[aria-selected] {
    background-color: #007bff !important;
    color: white !important;
}

.select2-container--default .select2-results__option[aria-selected=true] {
    background-color: #e9ecef !important;
    color: #495057 !important;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/attendances/calendar.blade.php ENDPATH**/ ?>