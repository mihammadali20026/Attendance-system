<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ATS - <?php echo $__env->yieldContent('title'); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <!-- Font Awesome -->
    <link href="<?php echo e(asset('assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">

    <!-- Custom Styles -->
    <link href="<?php echo e(asset('assets/admin/css/ats-style.min.css?ver=4')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/admin/css/ats-style.css?ver=9')); ?>" rel="stylesheet">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets/img/favicon.ico')); ?>">

    <!-- Yield for Additional Styles -->
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body>
    <!-- Loader -->
    <div class="loader"></div>

    <!-- Main App Content -->
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <!-- Scripts -->

    <!-- Core Libraries -->
    <script src="<?php echo e(asset('assets/vendor/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>

    <!-- Custom Scripts -->
    <script src="<?php echo e(asset('assets/admin/js/sb-admin-2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/app.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/scripts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/admin/js/custom.js')); ?>"></script>

    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <!-- Toast Notifications -->
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            width: '27rem',
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        <?php if(session()->has('message')): ?>
            // Set type of alert (info, success, warning, error)
            let type = "<?php echo e(session('alert', 'success')); ?>";  // Default to success if no type is set
            Toast.fire({
                icon: type,  // Dynamically set the icon type
                title: '<?php echo e(session("message")); ?>'  // Display the session message
            });
        <?php endif; ?>
        <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            Toast.fire({
                icon: 'error',
                title: '<?php echo e($error); ?>'  // Show the validation errors as toast notifications
            });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </script>


    <!-- Yield for Additional Scripts -->
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH E:\xampp\htdocs\brainx\AttendanceSystem\resources\views/admin/auth/layout/app.blade.php ENDPATH**/ ?>