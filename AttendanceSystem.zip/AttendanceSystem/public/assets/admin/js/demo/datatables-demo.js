$(document).ready(function() {
  $('#dataTable').DataTable({
    "paging": true,         // Enable pagination
    "searching": true,      // Enable search box
    "ordering": true,       // Enable column sorting
    "lengthMenu": [10, 25, 50, 100, 500], // Define page length options
    "pageLength": 10         // Set the default page length
  });
});
