# Employee Login API Documentation

## Base URL
```
http://your-domain.com/api
```

## Authentication
The API uses a custom token-based authentication system (NOT Laravel Sanctum). Include the token in the Authorization header:
```
Authorization: Bearer {your_token}
```

**Token Format:** The system generates a simple base64-encoded token containing user ID, timestamp, and device ID.
**Token Expiration:** Tokens are valid for 24 hours from generation.
**Session Validation:** Each request validates the token against active sessions in the database.

## Device Binding & Single Device Login Restriction
**Important**: This API implements both device binding and single device login restrictions:

### Device Binding (First-Time Login):
- When an employee logs in for the **first time**, their account gets bound to that specific device
- After the first login, the employee can **ONLY** login from that same registered device
- This prevents account sharing and unauthorized access from different devices

### Single Device Login:
- An employee can only be logged in on **ONE device at a time**
- If an employee tries to login on a new device while already logged in on another device, the login will be rejected
- The employee must logout from the current device before logging in on a new device

### Security Benefits:
- Prevents account sharing between multiple devices
- Ensures only the original device can access the account
- Prevents unauthorized access from different devices
- Maintains session security and device integrity

## Endpoints

### 1. Employee Login
**POST** `/api/employee/login`

**Request Body:**
```json
{
    "email": "employee@example.com",
    "password": "password123",
    "device_id": "unique_device_identifier_123"
}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Login successful",
    "data": {
        "user": {
            "id": 1,
            "name": "John Doe",
            "email": "employee@example.com",
            "type": "employee",
            "status": 1
        },
        "employee": {
            "id": 1,
            "position": "Developer",
            "work_type": 0,
            "work_type_label": "Inside Business Unit",
            "business_unit": {
                "id": 1,
                "name": "IT Department",
                "timezone": "America/New_York",
                "timezone_label": "Eastern Time"
            },
            "schedule": {
                "id": 1,
                "name": "Regular Hours",
                "time_in": "09:00:00",
                "time_out": "17:00:00"
            }
        },
        "device_id": "unique_device_identifier_123",
        "token": "1|abcdef123456...",
        "token_type": "Bearer"
    }
}
```

**Error Response (401):**
```json
{
    "success": false,
    "message": "Invalid credentials"
}
```

**Error Response (403) - Device Not Authorized:**
```json
{
    "success": false,
    "message": "This account is bound to another device. You can only login from the originally registered device.",
    "code": "DEVICE_NOT_AUTHORIZED"
}
```

**Error Response (409) - Already Logged In:**
```json
{
    "success": false,
    "message": "You are already logged in on another device. Please logout from the other device first.",
    "code": "ALREADY_LOGGED_IN"
}
```

### 2. Employee Logout
**POST** `/api/employee/logout`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Request Body:**
```json
{
    "device_id": "unique_device_identifier_123"
}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Logout successful"
}
```

### 3. Get Employee Profile
**GET** `/api/employee/profile`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Success Response (200):**
```json
{
    "success": true,
    "data": {
        "user": {
            "id": 1,
            "name": "John Doe",
            "email": "employee@example.com",
            "type": "employee",
            "status": 1
        },
        "employee": {
            "id": 1,
            "position": "Developer",
            "work_type": 0,
            "work_type_label": "Inside Business Unit",
            "business_unit": {
                "id": 1,
                "name": "IT Department",
                "timezone": "America/New_York",
                "timezone_label": "Eastern Time"
            },
            "schedule": {
                "id": 1,
                "name": "Regular Hours",
                "time_in": "09:00:00",
                "time_out": "17:00:00"
            }
        }
    }
}
```

### 4. Logout from All Devices
**POST** `/api/employee/logout-all`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Logged out from all devices successfully"
}
```

### 5. Check Login Status
**GET** `/api/employee/login-status`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "User is logged in",
    "data": {
        "user_id": 1,
        "device_id": "unique_device_identifier_123",
        "last_activity": 1699123456,
        "ip_address": "192.168.1.100"
    }
}
```

**Error Response (401) - No Active Session:**
```json
{
    "success": false,
    "message": "No active session found",
    "code": "NO_ACTIVE_SESSION"
}
```

### 6. Get Registered Device Info
**GET** `/api/employee/registered-device`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Registered device information retrieved",
    "data": {
        "registered_device_id": "original_device_123",
        "first_login_time": 1699123456,
        "ip_address": "192.168.1.100",
        "user_agent": "Mobile App v1.0"
    }
}
```

**Error Response (404) - No Registered Device:**
```json
{
    "success": false,
    "message": "No registered device found",
    "code": "NO_REGISTERED_DEVICE"
}
```

### 7. Reset Device Binding
**POST** `/api/employee/reset-device-binding`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Device binding has been reset. You can now login from any device.",
    "data": {
        "user_id": 1,
        "reset_time": 1699123456
    }
}
```

### 8. Update Device ID
**POST** `/api/employee/update-device`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Request Body:**
```json
{
    "device_id": "new_device_identifier_456"
}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Device ID updated successfully",
    "data": {
        "device_id": "new_device_identifier_456"
    }
}
```

## Error Codes

- **200**: Success
- **401**: Unauthorized (Invalid credentials, token, or no active session)
- **403**: Forbidden (Device not authorized - account bound to different device)
- **404**: Not Found (Employee details not found, no registered device)
- **409**: Conflict (Already logged in on another device)
- **422**: Validation Error
- **500**: Internal Server Error

## Device ID Storage

The `device_id` is stored in the `sessions` table along with:
- `user_id`: The employee's user ID
- `ip_address`: The IP address of the request
- `user_agent`: The user agent string
- `last_activity`: Timestamp of last activity

## Security Notes

1. All API endpoints require HTTPS in production
2. Tokens should be stored securely on the client side
3. Device IDs should be unique per device
4. Tokens can be revoked by logging out
5. Only employees with `type = 'employee'` and `status = 1` can login

## Attendance API Endpoints

### 9. Employee Check-in
**POST** `/api/attendance/check-in`

**Headers:**
```
Authorization: Bearer {your_token}
Content-Type: multipart/form-data (for outside employees with image upload)
```

**Request Body for Inside Employees (work_type = 0):**
```json
{
    "device_id": "unique_device_identifier_123",
    "location": "Office Building A",
    "notes": "Optional check-in notes",
    "latitude": 40.7128,
    "longitude": -74.0060
}
```

**Request Body for Outside Employees (work_type = 1):**
```
device_id: unique_device_identifier_123
location: Client Site Location
notes: Optional check-in notes
latitude: 40.7128
longitude: -74.0060
image: [IMAGE_FILE] (required - jpeg, png, jpg, gif, max 5MB)
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Check-in successful",
    "data": {
        "attendance_id": 1,
        "check_in_time": "09:15:30",
        "attendance_date": "2025-10-08",
        "late_minutes": 15,
        "status": "late",
        "status_label": "Late",
        "scheduled_check_in": "09:00:00",
        "is_late": true,
        "late_time_formatted": "15m late",
        "timezone": "America/New_York",
        "work_type": 1,
        "work_type_label": "Outside",
        "image_uploaded": true,
        "image_url": "http://your-domain.com/assets/admin/attendance_images/1_check_in_1699123456.jpg"
    }
}
```

### 10. Employee Check-out
**POST** `/api/attendance/check-out`

**Headers:**
```
Authorization: Bearer {your_token}
Content-Type: multipart/form-data (for outside employees with image upload)
```

**Request Body for Inside Employees (work_type = 0):**
```json
{
    "device_id": "unique_device_identifier_123",
    "location": "Office Building A",
    "notes": "Optional check-out notes",
    "latitude": 40.7128,
    "longitude": -74.0060
}
```

**Request Body for Outside Employees (work_type = 1):**
```
device_id: unique_device_identifier_123
location: Client Site Location
notes: Optional check-out notes
latitude: 40.7128
longitude: -74.0060
image: [IMAGE_FILE] (required - jpeg, png, jpg, gif, max 5MB)
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Check-out successful",
    "data": {
        "attendance_id": 1,
        "check_in_time": "09:15:30",
        "check_out_time": "17:30:45",
        "attendance_date": "2025-10-08",
        "total_working_minutes": 495,
        "working_time_formatted": "8h 15m",
        "early_departure_minutes": 0,
        "early_departure_formatted": "On Time",
        "status": "present",
        "status_label": "Present",
        "is_early_departure": false,
        "timezone": "America/New_York",
        "work_type": 1,
        "work_type_label": "Outside",
        "image_uploaded": true,
        "image_url": "http://your-domain.com/assets/admin/attendance_images/1_check_out_1699123456.jpg"
    }
}
```

### 11. Get Today's Attendance Status
**GET** `/api/attendance/today`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Today's attendance retrieved successfully",
    "data": {
        "attendance_id": 1,
        "attendance_date": "2025-10-08",
        "check_in_time": "09:15:30",
        "check_out_time": null,
        "scheduled_check_in": "09:00:00",
        "scheduled_check_out": "17:00:00",
        "late_minutes": 15,
        "early_departure_minutes": 0,
        "total_working_minutes": 0,
        "status": "late",
        "status_label": "Late",
        "is_checked_in": true,
        "is_checked_out": false,
        "late_time_formatted": "15m late",
        "early_departure_formatted": "On Time",
        "working_time_formatted": "N/A",
        "timezone": "America/New_York",
        "notes": "Optional notes"
    }
}
```

### 12. Get Attendance History
**GET** `/api/attendance/history`

**Headers:**
```
Authorization: Bearer {your_token}
```

**Query Parameters:**
- `start_date` (optional): Start date in Y-m-d format (default: 30 days ago)
- `end_date` (optional): End date in Y-m-d format (default: today)
- `limit` (optional): Number of records to return (default: 30, max: 100)

**Example Request:**
```
GET /api/attendance/history?start_date=2025-10-01&end_date=2025-10-08&limit=10
```

**Success Response (200):**
```json
{
    "success": true,
    "message": "Attendance history retrieved successfully",
    "data": {
        "attendances": [
            {
                "attendance_id": 1,
                "attendance_date": "2025-10-08",
                "check_in_time": "09:15:30",
                "check_out_time": "17:30:45",
                "scheduled_check_in": "09:00:00",
                "scheduled_check_out": "17:00:00",
                "late_minutes": 15,
                "early_departure_minutes": 0,
                "total_working_minutes": 495,
                "status": "late",
                "status_label": "Late",
                "late_time_formatted": "15m late",
                "early_departure_formatted": "On Time",
                "working_time_formatted": "8h 15m",
                "timezone": "America/New_York",
                "notes": "Optional notes"
            }
        ],
        "total_records": 1,
        "date_range": {
            "start_date": "2025-10-01",
            "end_date": "2025-10-08"
        },
        "pagination": {
            "limit": 10,
            "has_more": false
        }
    }
}
```

## Work Type Behavior

### Inside Employees (work_type = 0)
- Standard check-in/check-out process
- **Required GPS coordinates** (latitude and longitude) for location verification
- **Location verification** against business unit location (must be within 100 meters)
- No image upload required
- Basic location string can be provided

### Outside Employees (work_type = 1)
- **Required image upload** for both check-in and check-out
- **Required GPS coordinates** (latitude and longitude) for location recording
- **No location verification** - just records where the employee is
- Images are stored in `public/assets/admin/attendance_images/`
- Media records are created with polymorphic relationship to attendance

## Location Verification

- **Inside Employees (work_type = 0)**: The system verifies that the employee is within 100 meters of their business unit's registered location. If no location is set for the business unit, any location is allowed.
- **Outside Employees (work_type = 1)**: No location verification is performed. The system only records the GPS coordinates where the employee checked in/out.

## Image Storage

- Images are stored in `public/assets/admin/attendance_images/`
- Filename format: `{user_id}_{type}_{timestamp}.{extension}`
- Supported formats: JPEG, PNG, JPG, GIF
- Maximum file size: 5MB
- Images are linked to attendance records via the media table

## Testing

You can test the API using tools like:
- Postman
- cURL
- Insomnia
- Any HTTP client

Example cURL for login:
```bash
curl -X POST http://your-domain.com/api/employee/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "employee@example.com",
    "password": "password123",
    "device_id": "test_device_123"
  }'
```

Example cURL for check-in (inside employee):
```bash
curl -X POST http://your-domain.com/api/attendance/check-in \
  -H "Authorization: Bearer {your_token}" \
  -H "Content-Type: application/json" \
  -d '{
    "device_id": "test_device_123",
    "location": "Office Building A",
    "notes": "Starting work"
  }'
```

Example cURL for check-in (outside employee):
```bash
curl -X POST http://your-domain.com/api/attendance/check-in \
  -H "Authorization: Bearer {your_token}" \
  -F "device_id=test_device_123" \
  -F "location=Client Site" \
  -F "notes=Starting work at client site" \
  -F "latitude=40.7128" \
  -F "longitude=-74.0060" \
  -F "image=@/path/to/image.jpg"
```
