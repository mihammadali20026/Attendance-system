<div class="pagination">
    <ul class="pagination">
        <!-- Previous Page Link -->
        <li class="page-item @if ($paginator->onFirstPage()) disabled @endif">
            <a class="page-link" href="{{ $paginator->previousPageUrl() }}&per_page={{ request()->get('per_page', 10) }}">Previous</a>
        </li>

        @php
            $currentPage = $paginator->currentPage();
            $lastPage = $paginator->lastPage();
            $startPage = max(1, $currentPage - 2); // Show 2 pages before the current page
            $endPage = min($lastPage, $currentPage + 2); // Show 2 pages after the current page
            $perPage = request()->get('per_page', 10); // Get per_page parameter from request or default to 10
        @endphp

        <!-- First Page Link -->
        @if ($startPage > 1)
            <li class="page-item">
                <a class="page-link" href="{{ $paginator->url(1) }}&per_page={{ $perPage }}">1</a>
            </li>
            @if ($startPage > 2)
                <li class="page-item disabled">
                    <span class="page-link">...</span>
                </li>
            @endif
        @endif

        <!-- Page Number Links -->
        @for ($i = $startPage; $i <= $endPage; $i++)
            <li class="page-item @if ($i == $currentPage) active @endif">
                <a class="page-link" href="{{ $paginator->url($i) }}&per_page={{ $perPage }}">{{ $i }}</a>
            </li>
        @endfor

        <!-- Last Page Link -->
        @if ($endPage < $lastPage)
            @if ($endPage < $lastPage - 1)
                <li class="page-item disabled">
                    <span class="page-link">...</span>
                </li>
            @endif
            <li class="page-item">
                <a class="page-link" href="{{ $paginator->url($lastPage) }}&per_page={{ $perPage }}">{{ $lastPage }}</a>
            </li>
        @endif

        <!-- Next Page Link -->
        <li class="page-item @if (!$paginator->hasMorePages()) disabled @endif">
            <a class="page-link" href="{{ $paginator->nextPageUrl() }}&per_page={{ $perPage }}">Next</a>
        </li>
    </ul>
</div>
