@extends('admin.layout.app')
@section('title', 'Create Business Unit')
@section('content')
<div class="container-fluid">
    <!-- Create Business Unit -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Create Business Unit</h6>
            <div>
                <a href="{{ route('admin.business-unit.index') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.business-unit.store') }}" method="POST">
                @csrf
                <div class="row">
                    <!-- Business Unit Name -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">Business Unit Name <span class="text-danger">*</span></label>
                            <input type="text" name="name" class="form-control @error('name') is-invalid @enderror" 
                                   id="name" placeholder="Enter Business Unit Name" value="{{ old('name') }}" required>
                            @error('name')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Timezone -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="timezone">Timezone <span class="text-danger">*</span></label>
                            <select name="timezone" id="timezone" class="form-control select2 @error('timezone') is-invalid @enderror" required>
                                <option value="">Select Timezone</option>
                                @foreach ($timezones as $key => $value)
                                    <option value="{{ $key }}" {{ old('timezone') == $key ? 'selected' : '' }}>{{ $value }}</option>
                                @endforeach
                            </select>
                            @error('timezone')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Status -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status">Status <span class="text-danger">*</span></label>
                            <select name="status" id="status" class="form-control @error('status') is-invalid @enderror" required>
                                <option value="">Select Status</option>
                                <option value="1" {{ old('status') == '1' ? 'selected' : '' }}>Active</option>
                                <option value="0" {{ old('status') == '0' ? 'selected' : '' }}>Inactive</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <!-- Location Section -->
                <div class="row">
                    <div class="col-12">
                        <h6 class="font-weight-bold text-primary mb-3">
                            <i class="fas fa-map-marker-alt"></i> Location Settings
                        </h6>
                    </div>
                </div>

                <div class="row">
                    <!-- Latitude -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="latitude">Latitude</label>
                            <input type="number" name="latitude" class="form-control @error('latitude') is-invalid @enderror" 
                                   id="latitude" placeholder="e.g., 40.7128" step="0.00000001" min="-90" max="90" value="{{ old('latitude') }}">
                            <small class="form-text text-muted">Enter the latitude coordinate of the business unit</small>
                            @error('latitude')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Longitude -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="longitude">Longitude</label>
                            <input type="number" name="longitude" class="form-control @error('longitude') is-invalid @enderror" 
                                   id="longitude" placeholder="e.g., -74.0060" step="0.00000001" min="-180" max="180" value="{{ old('longitude') }}">
                            <small class="form-text text-muted">Enter the longitude coordinate of the business unit</small>
                            @error('longitude')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Radius -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="radius_meters">Check-in Radius (meters)</label>
                            <input type="number" name="radius_meters" class="form-control @error('radius_meters') is-invalid @enderror" 
                                   id="radius_meters" placeholder="100" min="1" max="10000" value="{{ old('radius_meters', 100) }}">
                            <small class="form-text text-muted">Maximum distance from office for check-in (1-10000 meters)</small>
                            @error('radius_meters')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle"></i>
                            <strong>Location Information:</strong> 
                            Set the exact location coordinates and radius for this business unit. 
                            Employees will only be able to check in when they are within the specified radius of this location.
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Create Business Unit
                    </button>
                    <a href="{{ route('admin.business-unit.index') }}" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
@section('js')
<script>
    $(document).ready(function() {
        $('#timezone').select2({
            placeholder: 'Select Timezone',
            allowClear: true,
            width: '100%'
        });
    });
    </script>
@endsection