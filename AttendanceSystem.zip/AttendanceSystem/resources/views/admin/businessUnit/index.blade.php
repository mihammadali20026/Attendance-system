@extends('admin.layout.app')
@section('title', 'Business Unit')
@section('content')
    <div class="container-fluid">
        <!-- Create New Applicant -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex align-items-center justify-content-between">
                <h6 class="m-2 font-weight-bold text-primary">Business Unit</h6>
                <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                    <div>
                        <a href="{{ route('admin.business-unit.create') }}" class="btn btn-primary text-white" title="Add Business Unit">
                            <i class="fas fa-plus"></i> Add Business Unit
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- Data view for applicants -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Business Unit Name</th>
                                <th>Timezone</th>
                                <th>Location</th>
                                <th>Status</th>
                                <th>Employees Count</th>
                                <th>Created At</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $key => $unit)
                                <tr>
                                    <td>{{ ++$key }}</td>
                                    <td>{{ $unit->name }}</td>
                                    <td>
                                        <span class="badge bg-info">{{ $unit->getTimezoneLabel() }}</span>
                                    </td>
                                    <td>
                                        @if($unit->latitude && $unit->longitude)
                                            <div class="text-sm">
                                                <i class="fas fa-map-marker-alt text-primary"></i>
                                                <span class="text-muted">{{ number_format($unit->latitude, 6) }}, {{ number_format($unit->longitude, 6) }}</span>
                                                <br>
                                                <small class="text-success">Radius: {{ $unit->radius_meters }}m</small>
                                            </div>
                                        @else
                                            <span class="text-muted">Not Set</span>
                                        @endif
                                    </td>
                                    <td>
                                        @if($unit->status == 1)
                                            <span class="badge bg-success">Active</span>
                                        @else
                                            <span class="badge bg-danger">Inactive</span>
                                        @endif
                                    </td>
                                    <td>
                                        <span class="badge bg-primary">{{ $unit->employees->count() }} Employee(s)</span>
                                    </td>
                                    <td>{{ $unit->created_at->format('d M, Y') }}</td>
                                    <td>
                                        <div class="crud-icons d-flex align-items-center justify-content-center gap-3 rounded p-2">
                                            <div>
                                                <a href="{{ route('admin.business-unit.show', $unit->id) }}" class="btn btn-primary text-white" title="View">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            </div>
                                            <div>
                                                <a href="{{ route('admin.business-unit.edit', $unit->id) }}" class="btn btn-warning mx-3 text-white" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                            <div>
                                                <form action="{{ route('admin.business-unit.destroy', $unit->id) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this business unit?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger text-white" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
