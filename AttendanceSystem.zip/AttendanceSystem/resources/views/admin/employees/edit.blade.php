@extends('admin.layout.app')
@section('title', 'Edit Employee')
@section('content')
    <div class="container-fluid">
        <!-- Edit Employee Form -->
        <div class="card mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Employee</h6>
            </div>
            <div class="card-body">
                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <form action="{{ route('admin.employees.update', $employee->id) }}" method="POST">
                    @csrf
                    @method('PUT')
                    
                    <h5 class="mb-3 text-secondary">User Information</h5>
                    <div class="row">
                        <!-- Name -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="name">Full Name <span class="text-danger">*</span></label>
                                <input type="text" name="name" class="form-control" id="name" placeholder="Enter Full Name" value="{{ old('name', $employee->user->name) }}" required>
                            </div>
                        </div>

                        <!-- Email -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email <span class="text-danger">*</span></label>
                                <input type="email" name="email" class="form-control" id="email" placeholder="Enter Email" value="{{ old('email', $employee->user->email) }}" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password">Password <small class="text-muted">(Leave blank to keep current)</small></label>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Enter New Password">
                            </div>
                        </div>

                        <!-- Confirm Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="password_confirmation">Confirm Password</label>
                                <input type="password" name="password_confirmation" class="form-control" id="password_confirmation" placeholder="Confirm Password">
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Status -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="status">Status <span class="text-danger">*</span></label>
                                <select name="status" id="status" class="form-control select2">
                                    <option value="1" {{ old('status', $employee->user->status) == '1' ? 'selected' : '' }}>Active</option>
                                    <option value="0" {{ old('status', $employee->user->status) == '0' ? 'selected' : '' }}>Inactive</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <hr class="my-4">

                    <h5 class="mb-3 text-secondary">Employee Details</h5>
                    <div class="row">
                        <!-- Business Unit -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="business_unit_id">Business Unit <span class="text-danger">*</span></label>
                                <select name="business_unit_id" id="business_unit_id" class="form-control select2" required>
                                    <option value="">Select Business Unit</option>
                                    @foreach ($businessUnits as $businessUnit)
                                        <option value="{{ $businessUnit->id }}" {{ old('business_unit_id', $employee->business_unit_id) == $businessUnit->id ? 'selected' : '' }}>
                                            {{ $businessUnit->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <!-- Position -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="position">Position <span class="text-danger">*</span></label>
                                <input type="text" name="position" class="form-control" id="position" placeholder="e.g., Manager, Developer" value="{{ old('position', $employee->position) }}" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Schedule -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="schedule_id">Schedule</label>
                                <select name="schedule_id" id="schedule_id" class="form-control select2">
                                    <option value="">Select Schedule (Optional)</option>
                                    @foreach ($schedules as $schedule)
                                        <option value="{{ $schedule->id }}" {{ old('schedule_id', $employee->schedule_id) == $schedule->id ? 'selected' : '' }}>
                                            {{ $schedule->name }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <!-- Work Type -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="work_type">Work Type <span class="text-danger">*</span></label>
                                <select name="work_type" id="work_type" class="form-control select2" required>
                                    <option value="">Select Work Type</option>
                                    <option value="0" {{ old('work_type', $employee->work_type) == '0' ? 'selected' : '' }}>Inside</option>
                                    <option value="1" {{ old('work_type', $employee->work_type) == '1' ? 'selected' : '' }}>Outside</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mt-3">Update</button>
                    <a href="{{ route('admin.employees.index') }}" class="btn btn-secondary mt-3">Cancel</a>
                </form>

            </div>
        </div>
    </div>
@endsection

