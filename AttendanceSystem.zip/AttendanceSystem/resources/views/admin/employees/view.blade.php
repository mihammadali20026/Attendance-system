@extends('admin.layout.app')
@section('title', 'View Employee')
@section('content')
    <div class="container-fluid">
        <!-- View Employee Details -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-primary">View Employee Details</h6>
                <div>
                    <a href="{{ route('admin.employees.edit', $employee->id) }}" class="btn btn-warning text-white">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="{{ route('admin.employees.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Back to List
                    </a>
                </div>
            </div>
            <div class="card-body">
                <h5 class="mb-3 text-secondary border-bottom pb-2">User Information</h5>
                <div class="row">
                    <!-- Name -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name"><strong>Full Name</strong></label>
                            <input type="text" class="form-control" value="{{ $employee->user->name }}" disabled readonly>
                        </div>
                    </div>

                    <!-- Email -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email"><strong>Email</strong></label>
                            <input type="email" class="form-control" value="{{ $employee->user->email }}" disabled readonly>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Status -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status"><strong>Status</strong></label>
                            <div class="mt-2">
                                @if($employee->user->status == 1)
                                    <span class="badge bg-success p-2">Active</span>
                                @else
                                    <span class="badge bg-danger p-2">Inactive</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="my-4">

                <h5 class="mb-3 text-secondary border-bottom pb-2">Employee Details</h5>
                <div class="row">
                    <!-- Business Unit -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="business_unit"><strong>Business Unit</strong></label>
                            <input type="text" class="form-control" value="{{ $employee->businessUnit->name ?? 'N/A' }}" disabled readonly>
                        </div>
                    </div>

                    <!-- Position -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="position"><strong>Position</strong></label>
                            <input type="text" class="form-control" value="{{ $employee->position }}" disabled readonly>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Schedule -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="schedule"><strong>Schedule</strong></label>
                            <input type="text" class="form-control" value="{{ $employee->schedule->name ?? 'Not Assigned' }}" disabled readonly>
                        </div>
                    </div>

                    <!-- Work Type -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="work_type"><strong>Work Type</strong></label>
                            <div class="mt-2">
                                @if($employee->work_type == 0)
                                    <span class="badge bg-success p-2">Inside Business Unit</span>
                                @else
                                    <span class="badge bg-info p-2">Outside Business Unit</span>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>

                <hr class="my-4">

                <h5 class="mb-3 text-secondary border-bottom pb-2">Additional Information</h5>
                <div class="row">
                    <!-- Created At -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="created_at"><strong>Employee Since</strong></label>
                            <input type="text" class="form-control" value="{{ $employee->created_at->format('d M, Y h:i A') }}" disabled readonly>
                        </div>
                    </div>

                    <!-- Updated At -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="updated_at"><strong>Last Updated</strong></label>
                            <input type="text" class="form-control" value="{{ $employee->updated_at->format('d M, Y h:i A') }}" disabled readonly>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
@endsection

