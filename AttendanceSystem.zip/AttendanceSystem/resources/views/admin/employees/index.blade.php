@extends('admin.layout.app')
@section('title', 'Employees')
@section('content')
<div class="container-fluid">
    <!-- Create New Employee -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-2 font-weight-bold text-primary">Employees</h6>
            <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                <div>
                    <a href="{{ route('admin.employees.create') }}" class="btn btn-primary text-white" title="Add Employee">
                        <i class="fas fa-plus"></i>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <!-- Data view for employees -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive card-body">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Business Unit</th>
                            <th>Position</th>
                            <th>Work Type</th>
                            <th>Schedule</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $key => $employee)
                        <tr>
                            <td>{{ ++$key }}</td>
                            <td>{{ $employee->user->name }}</td>
                            <td>{{ $employee->user->email }}</td>
                            <td>{{ $employee->businessUnit->name ?? 'N/A' }}</td>
                            <td>{{ $employee->position }}</td>
                            <td>
                                @if($employee->work_type == 0)
                                    <span class="badge bg-success">Inside Business Unit</span>
                                @else
                                    <span class="badge bg-info">Outside Business Unit</span>
                                @endif
                            </td>
                            <td>{{ $employee->schedule->name ?? 'Not Assigned' }}</td>
                            <td>
                                @if($employee->user->status == 1)
                                    <span class="badge bg-success">Active</span>
                                @else
                                    <span class="badge bg-danger">Inactive</span>
                                @endif
                            </td>
                            <td>
                                <div class="crud-icons d-flex align-items-center justify-content-center gap-3 rounded p-2">
                                    <div>
                                        <a href="{{ route('admin.employees.show', $employee->id) }}" class="btn btn-primary text-white" title="View">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    </div>
                                    <div>
                                        <a href="{{ route('admin.employees.edit', $employee->id) }}" class="btn btn-warning mx-3 text-white" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                    <div>
                                        <form action="{{ route('admin.employees.destroy', $employee->id) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this employee?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger text-white" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
@endsection

