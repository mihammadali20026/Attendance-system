<!DOCTYPE html>
<html lang="en">
<!-- index.html  21 Nov 2019 03:44:50 GMT -->

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Nixxe Solutions - @yield('title')</title>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />

    <!-- Font Awesome -->
    <link href="{{ asset('assets/vendor/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <!-- Custom Styles -->
    <link href="{{ asset('assets/admin/css/ats-style.min.css?ver=4') }}" rel="stylesheet">
    <link href="{{ asset('assets/admin/css/ats-style.css?ver=9') }}" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="{{asset('assets/admin/css/datatable/jquery.dataTables.min.css?ver=3')}}">

    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="{{ asset('assets/admin/img/favicon.png') }}">
</head>

<body id="page-top">
    <div class="loader"></div>
    <div id="wrapper">
        @include('admin.components.sidebar')
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                @include('admin.components.header')
                @yield('content')
                @include('admin.components.footer')
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="{{ asset('assets/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('assets/vendor/jquery-easing/jquery.easing.min.js') }}"></script>

    <!-- Custom Scripts -->
    <script src="{{ asset('assets/admin/js/sb-admin-2.min.js') }}"></script>

    <!-- Sweet Alert -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- DataTables and related scripts -->
    <script src="https://cdn.datatables.net/1.10.24/js/jquery.dataTables.min.js?ver=3"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <script src="https://cdn.ckeditor.com/ckeditor5/39.0.0/classic/ckeditor.js"></script>
    {{-- <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyArp82ZppeyHTz_VlfoHOb871xb7iYHGRs&libraries=places&callback=initAutocomplete" async defer></script> --}}

    <!-- Page level plugins -->
    <script src="{{ asset('assets/vendor/chart.js/Chart.min.js') }}"></script>

    <!-- Page level custom scripts -->
    <script src="{{ asset('assets/admin/js/demo/chart-area-demo.js') }}"></script>
    <script src="{{ asset('assets/admin/js/demo/chart-pie-demo.js') }}"></script>
    @if (!Route::is('admin.applicants.index'))
    <script src="{{ asset('assets/admin/js/demo/datatables-demo.js?ver=4') }}"></script>
    @endif



    <!-- Toastr Popup -->
    {{-- <script>
     function toastrPopUp() {
         toastr.options = {
             "closeButton": true,
             "newestOnTop": false,
             "progressBar": true,
             "positionClass": "toast-top-right",
             "preventDuplicates": false,
             "onclick": null,
             "showDuration": "3000",
             "hideDuration": "1000",
             "timeOut": "5000",
             "extendedTimeOut": "1000",
             "showEasing": "swing",
             "hideEasing": "linear",
             "showMethod": "fadeIn",
             "hideMethod": "fadeOut"
         };
     }

     toastrPopUp();
 </script> --}}
    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3000,
            width: '27rem',
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.addEventListener('mouseenter', Swal.stopTimer);
                toast.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });

        @if (session()->has('message'))
            // Set type of alert (info, success, warning, error)
            let type = "{{ session('alert', 'success') }}"; // Default to success if no type is set
            Toast.fire({
                icon: type, // Dynamically set the icon type
                title: '{{ session('message') }}' // Display the session message
            });
        @endif
        @if ($errors->any())
            @foreach ($errors->all() as $error)
                Toast.fire({
                    icon: 'error',
                    title: '{{ $error }}' // Show the validation errors as toast notifications
                });
            @endforeach
        @endif
    </script>

    @yield('js')
    
    <!-- Modals Section -->
    @stack('modals')

</body>

</html>
