@extends('admin.layout.app')
@section('title', 'Users')
@section('content')
<div class="container-fluid">
    <!-- Create New Applicant -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-2 font-weight-bold text-primary">Users</h6>
            <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                @can('users-create')
                <div>
                    <a href="{{ route('admin.users.create') }}" class="btn btn-primary text-white" title="Add">
                        <i class="fas fa-plus"></i>
                    </a>
                </div>
                @endcan

            </div>
        </div>
    </div>
    <!-- Data view for applicants -->
    <div class="card shadow mb-4">
        <div class="card-body">
            <div class="table-responsive card-body">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Member Since</th>
                            @canany(['users-edit', 'users-delete'])
                            <th>Action</th>
                            @endcanany

                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($data as $key => $user)
                        <tr>
                            <td>{{ ++$key }}</td>
                            <td>{{ $user->name }}</td>
                            <td>{{ $user->email }}</td>

                            <td>
                                @if (!empty($user->getRoleNames()))
                                @foreach ($user->getRoleNames() as $v)
                                <label class="badge bg-success">{{ $v }}</label>
                                @endforeach
                                @endif
                            </td>
                            <td>{{ $user->created_at->format('d M, Y') }}</td>
                            <td>
                                <div
                                    class="crud-icons d-flex align-items-center justify-content-center gap-3  rounded p-2">
                                    @can('users-view')
                                    <div><a href="{{ route('admin.users.show', $user->id) }}"
                                            class="btn btn-primary text-white" title="view"><i
                                                class="fa fa-eye"></i></a>
                                    </div>
                                    @endcan
                                    @can('users-edit')
                                    <div>
                                        <a href="{{ route('admin.users.edit', $user->id) }}"
                                            class="btn btn-warning mx-3 text-white" title="Edit"><i
                                                class="fas fa-edit"></i></a>
                                    </div>
                                    @endcan
                                    @can('users-delete')
                                    <div>
                                        <form action="{{ route('admin.users.destroy', $user->id) }}" method="POST"
                                            style="display: inline;"
                                            onsubmit="return confirm('Are you sure you want to delete this user?');">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger text-white" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </form>
                                    </div>
                                    @endcan
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
@section('script')
@endsection