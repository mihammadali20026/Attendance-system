@extends('admin.layout.app')
@section('title', 'View User')
@section('content')
    <div class="container-fluid">
        <!-- Add Role Form -->
        <div class="card mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">View User</h6>
            </div>
            <div class="card-body">
                    <div class="row">
                        <!-- First Name -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="firstname">First Name</label>
                                <input type="text" name="firstname" class="form-control" value="{{$user->firstname}}" id="firstname" disabled readonly placeholder="Enter First Name" required>
                            </div>
                        </div>

                        <!-- Last Name -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="lastname">Last Name</label>
                                <input type="text" name="lastname" class="form-control" value="{{$user->lastname}}" id="lastname" disabled readonly placeholder="Enter Last Name" required>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Email -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" name="email" class="form-control" value="{{$user->email}}" id="email" disabled readonly placeholder="Enter Email" required>
                            </div>
                        </div>

                        <!-- Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="email">Phone</label>
                                <input type="text" name="phone" class="form-control" value="{{$user->phone}}" id="phone" disabled readonly placeholder="Enter Phone">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="roles">Organization</label>
                                <select name="business_unit_id" class="form-control select2" disabled readonly>
                                    @foreach ($units as $value => $unit)
                                    <option value="{{ $unit->id }}"
                                        @if ($unit->id == old('business_unit_id', $user->business_unit_id)) selected @endif>
                                        {{ $unit->name }}
                                    </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>

                        <!-- Password -->
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="roles">Role</label>
                                <select name="roles[]" class="form-control select2" disabled readonly>
                                    @foreach ($roles as $value => $label)
                                            <option value="{{ $value }}" {{ isset($userRole[$value]) ? 'selected' : ''}}>
                                                {{ $label }}
                                            </option>
                                         @endforeach
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select name="status" id="status" class="form-control select2" disabled readonly>
                                    <option value="1" {{ old('status', $user->status) == 1 ? 'selected' : '' }}>Active</option>
                                    <option value="0" {{ old('status', $user->status) == 0 ? 'selected' : '' }}>InActive</option>
                                </select>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
@endsection
@section('js')
<script>
    $(document).ready(function() {
        // Function to toggle the 'assign_user' and 'ownership' dropdowns
        function toggleFieldsBasedOnStatus() {
            if ($('#status').val() === '0') {
                // If "Inactive" is selected, enable the 'assign_user' and 'ownership' dropdowns
                $('#assign_user').prop('disabled', false);
                $('#ownership').prop('disabled', false);
            } else {
                // If "Active" is selected, disable the 'assign_user' and 'ownership' dropdowns
                $('#assign_user').prop('disabled', true);
                $('#ownership').prop('disabled', true);
            }
        }

        // Call the function on page load to set the initial state based on status
        toggleFieldsBasedOnStatus();

        // Handle change event for status dropdown
        $('#status').on('change', function() {
            toggleFieldsBasedOnStatus();
        });

        // Initialize select2 for ownership
        $('#ownership').select2({
            placeholder: "Select options",
            allowClear: true
        });
    });
</script>





@endsection
