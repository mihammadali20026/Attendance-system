@extends('admin.layout.app')
@section('title', 'Edit User')
@section('content')
<div class="container-fluid">
    <!-- Add Role Form -->
    <div class="card mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit User</h6>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.users.update',$user->id) }}" method="POST">
                @csrf
                @method('PUT')
                <div class="row">
                    <!-- First Name -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="name">Name</label>
                            <input type="text" name="name" class="form-control" value="{{$user->name}}"
                                id="name" placeholder="Enter Full Name" required>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control" value="{{$user->email}}" id="email"
                                placeholder="Enter Email" required>
                        </div>
                    </div>

                </div>
                <div class="row">
                    <!-- Password -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="roles">Role</label>
                            <select name="roles[]" class="form-control select2">
                                @foreach ($roles as $value => $label)
                                <option value="{{ $value }}" {{ isset($userRole[$value]) ? 'selected' : '' }}>
                                    {{ $label }}
                                </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status">Status</label>
                            <select name="status" id="status" class="form-control select2">
                                <option value="1" {{ old('status', $user->status) == 1 ? 'selected' : '' }}>Active
                                </option>
                                <option value="0" {{ old('status', $user->status) == 0 ? 'selected' : '' }}>InActive
                                </option>
                            </select>
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Update</button>
                <a href="{{ route('admin.users.index') }}" class="btn btn-secondary mt-3">Cancel</a>
            </form>

        </div>
    </div>
</div>
@endsection
@section('js')
@endsection