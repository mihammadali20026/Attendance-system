@extends('admin.layout.app')
@section('title', 'Roles')
@section('content')
    <div class="container-fluid">
        <!-- Create New Applicant -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex align-items-center justify-content-between">
                <h6 class="m-2 font-weight-bold text-primary">Roles</h6>
                <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                    @can('roles-create')
                    <div>
                        <a href="{{ route('admin.roles.create') }}" class="btn btn-primary text-white" title="Add">
                            <i class="fas fa-plus"></i> Add Role
                        </a>
                    </div>
                    @endcan

                </div>
            </div>
        </div>
        <!-- Data view for applicants -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                @canany(['users-edit', 'users-delete'])
                                    <th>Action</th>
                                @endcanany
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($roles as $key => $role)
                                <tr>
                                    <td>{{ ++$key }}</td>
                                    <td>
                                        @if (!empty($role->name))
                                            <label class="btn btn-success text-white">{{ $role->name }}</label>
                                        @endif
                                    </td>
                                    {{-- <td>
                                    @if (!empty($role->getRoleNames()))
                                        @foreach ($role->getRoleNames() as $v)
                                            <label class="badge bg-success">{{ $v }}</label>
                                        @endforeach
                                    @endif
                                </td> --}}
                                    <td>
                                        <div
                                            class="crud-icons d-flex align-items-center justify-content-center gap-3  rounded p-2">
                                            @can('roles-edit')
                                            <div>
                                                <a href="{{ route('admin.roles.edit', $role->id) }}"
                                                    class="btn btn-warning mx-3 text-white" title="Edit"><i
                                                        class="fas fa-edit"></i></a>
                                            </div>
                                            @endcan
                                            @can('roles-delete')
                                            <div>
                                                <form action="{{ route('admin.roles.destroy', $role->id) }}" method="POST" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this user?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger text-white" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div>
                                            @endcan
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('script')
@endsection
