@extends('admin.layout.app')
@section('title', 'Add Role')
@section('content')
    <div class="container-fluid">
        <!-- Add Role Form -->
        <div class="card mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Add New Role</h6>
            </div>
            <div class="card-body">
                <form action="{{ route('admin.roles.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="roleName">Role Name</label>
                        <input type="text" name="name" class="form-control" id="roleName"
                            placeholder="Enter Role Name" required>
                    </div>
                    <div class="form-group">
                        <label for="permissions">Permissions:</label>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Sr</th>
                                    <th>Module</th>
                                    <th>Permissions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @php $counter = 1; @endphp
                                @foreach ($groupedPermissions as $module => $permissions)
                                    <tr>
                                        <td>{{ $counter++ }}</td>
                                        <td>{{ ucfirst($module) }}</td>
                                        <td style="padding-left: 20%">
                                            <div style="display: flex; flex-wrap: wrap; gap: 40px;">
                                                @foreach ($permissions as $permission)
                                                    <div style="display: flex; align-items: center; gap: 5px;">
                                                        <input type="checkbox" name="permission[]" value="{{ $permission->id }}"
                                                            @if (in_array($permission->id, old('permission', []))) checked @endif>
                                                        <label style="margin-top: 10px">{{ ucfirst(Str::after($permission->name, '-')) }}</label>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{-- <div class="form-group">
                        <strong>Permission:</strong>
                        <br/>
                        @foreach ($permissions as $value)
                            <label><input type="checkbox" name="permission[{{$value->id}}]" value="{{$value->id}}" class="name">
                            {{ $value->name }}</label>
                        <br/>
                        @endforeach
                    </div> --}}
                    <button type="submit" class="btn btn-primary mt-3">Submit</button>
                    <a href="{{ route('admin.roles.index') }}" class="btn btn-secondary mt-3">Cancel</a>
                </form>
            </div>
        </div>
    </div>
@endsection
