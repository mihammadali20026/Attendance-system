@extends('admin.layout.app')
@section('title', 'Edit Role')
@section('content')
    <div class="container-fluid">
        <!-- Add Role Form -->
        <div class="card mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Edit Role</h6>
            </div>
            <div class="card-body">
                <form method="POST" action="{{ route('admin.roles.update', $role->id) }}">
                    @csrf
                    @method('PUT')
                    <div class="form-group">
                        <label for="roleName">Role Name</label>
                        <input type="text" name="name" placeholder="Name" class="form-control"
                            value="{{ $role->name }}">
                    </div>
                    <div class="form-group">
                        <label for="permissions">Permissions:</label>
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Module</th>
                                    <th>Permissions</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($groupedPermissions as $module => $permissions)
                                    <tr>
                                        <td>{{ ucfirst($module) }}</td>
                                        <td style="padding-left: 20%">
                                            <div style="display: flex; flex-wrap: wrap; gap: 40px;">
                                                @foreach ($permissions as $permission)
                                                    <div style="display: flex; align-items: center; gap: 5px;">
                                                        <input
                                                            type="checkbox"
                                                            name="permission[]"
                                                            value="{{ $permission->id }}"
                                                            @if (in_array($permission->id, $rolePermissions)) checked @endif
                                                        >
                                                        <label style="margin-top: 10px;">{{ ucfirst(Str::after($permission->name, '-')) }}</label>
                                                    </div>
                                                @endforeach
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Update</button>
                    <a href="{{ route('admin.roles.index') }}" class="btn btn-secondary mt-3">Cancel</a>
                </form>
            </div>
        </div>
    </div>
@endsection
