@extends('admin.layout.app')
@section('title', 'Edit Attendance')
@section('content')
<div class="container-fluid">
    <!-- Edit Attendance Form -->
    <div class="card mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Edit Attendance Record</h6>
        </div>
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('admin.attendances.update', $attendance->id) }}" method="POST">
                @csrf
                @method('PUT')
                
                <div class="row">
                    <!-- Employee Selection -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="user_id">Employee <span class="text-danger">*</span></label>
                            <select name="user_id" id="user_id" class="form-control @error('user_id') is-invalid @enderror" required>
                                <option value="">Select Employee</option>
                                @foreach($employees as $employee)
                                    <option value="{{ $employee->id }}" {{ (old('user_id', $attendance->user_id) == $employee->id) ? 'selected' : '' }}>
                                        {{ $employee->name }} - {{ $employee->employeeDetail->businessUnit->name ?? 'N/A' }}
                                    </option>
                                @endforeach
                            </select>
                            @error('user_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Attendance Date -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="attendance_date">Attendance Date <span class="text-danger">*</span></label>
                            <input type="date" name="attendance_date" id="attendance_date" 
                                   class="form-control @error('attendance_date') is-invalid @enderror" 
                                   value="{{ old('attendance_date', $attendance->attendance_date->format('Y-m-d')) }}" required>
                            @error('attendance_date')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Check In Time -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_in_time">Check In Time</label>
                            <input type="time" name="check_in_time" id="check_in_time" 
                                   class="form-control @error('check_in_time') is-invalid @enderror" 
                                   value="{{ old('check_in_time', $attendance->check_in_time ? \Carbon\Carbon::parse($attendance->check_in_time)->format('H:i') : '') }}">
                            @error('check_in_time')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Check Out Time -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_out_time">Check Out Time</label>
                            <input type="time" name="check_out_time" id="check_out_time" 
                                   class="form-control @error('check_out_time') is-invalid @enderror" 
                                   value="{{ old('check_out_time', $attendance->check_out_time ? \Carbon\Carbon::parse($attendance->check_out_time)->format('H:i') : '') }}">
                            @error('check_out_time')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Status -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status">Status <span class="text-danger">*</span></label>
                            <select name="status" id="status" class="form-control @error('status') is-invalid @enderror" required>
                                <option value="">Select Status</option>
                                <option value="present" {{ old('status', $attendance->status) == 'present' ? 'selected' : '' }}>Present</option>
                                <option value="late" {{ old('status', $attendance->status) == 'late' ? 'selected' : '' }}>Late</option>
                                <option value="absent" {{ old('status', $attendance->status) == 'absent' ? 'selected' : '' }}>Absent</option>
                                <option value="half_day" {{ old('status', $attendance->status) == 'half_day' ? 'selected' : '' }}>Half Day</option>
                                <option value="overtime" {{ old('status', $attendance->status) == 'overtime' ? 'selected' : '' }}>Overtime</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Device ID -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="device_id">Device ID</label>
                            <input type="text" name="device_id" id="device_id" 
                                   class="form-control @error('device_id') is-invalid @enderror" 
                                   value="{{ old('device_id', $attendance->device_id) }}" placeholder="Enter device ID">
                            @error('device_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Check In Location -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_in_location">Check In Location</label>
                            <input type="text" name="check_in_location" id="check_in_location" 
                                   class="form-control @error('check_in_location') is-invalid @enderror" 
                                   value="{{ old('check_in_location', $attendance->check_in_location) }}" placeholder="Enter check-in location">
                            @error('check_in_location')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Check Out Location -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_out_location">Check Out Location</label>
                            <input type="text" name="check_out_location" id="check_out_location" 
                                   class="form-control @error('check_out_location') is-invalid @enderror" 
                                   value="{{ old('check_out_location', $attendance->check_out_location) }}" placeholder="Enter check-out location">
                            @error('check_out_location')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Notes -->
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="notes">Notes</label>
                            <textarea name="notes" id="notes" rows="3" 
                                      class="form-control @error('notes') is-invalid @enderror" 
                                      placeholder="Enter any additional notes">{{ old('notes', $attendance->notes) }}</textarea>
                            @error('notes')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Update Attendance Record
                    </button>
                    <a href="{{ route('admin.attendances.index') }}" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
