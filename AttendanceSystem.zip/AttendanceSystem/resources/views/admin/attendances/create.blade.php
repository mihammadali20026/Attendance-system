@extends('admin.layout.app')
@section('title', 'Add Attendance')
@section('content')
<div class="container-fluid">
    <!-- Add Attendance Form -->
    <div class="card mb-4">
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Add Attendance Record</h6>
        </div>
        <div class="card-body">
            @if ($errors->any())
                <div class="alert alert-danger">
                    <ul>
                        @foreach ($errors->all() as $error)
                            <li>{{ $error }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <form action="{{ route('admin.attendances.store') }}" method="POST">
                @csrf
                
                <div class="row">
                    <!-- Employee Selection -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="user_id">Employee <span class="text-danger">*</span></label>
                            <select name="user_id" id="user_id" class="form-control @error('user_id') is-invalid @enderror" required>
                                <option value="">Select Employee</option>
                                @foreach($employees as $employee)
                                    <option value="{{ $employee->id }}" {{ old('user_id') == $employee->id ? 'selected' : '' }}>
                                        {{ $employee->name }} - {{ $employee->employeeDetail->businessUnit->name ?? 'N/A' }}
                                    </option>
                                @endforeach
                            </select>
                            @error('user_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Attendance Date -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="attendance_date">Attendance Date <span class="text-danger">*</span></label>
                            <input type="date" name="attendance_date" id="attendance_date" 
                                   class="form-control @error('attendance_date') is-invalid @enderror" 
                                   value="{{ old('attendance_date', date('Y-m-d')) }}" required>
                            @error('attendance_date')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Check In Time -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_in_time">Check In Time</label>
                            <input type="time" name="check_in_time" id="check_in_time" 
                                   class="form-control @error('check_in_time') is-invalid @enderror" 
                                   value="{{ old('check_in_time') }}">
                            @error('check_in_time')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Check Out Time -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_out_time">Check Out Time</label>
                            <input type="time" name="check_out_time" id="check_out_time" 
                                   class="form-control @error('check_out_time') is-invalid @enderror" 
                                   value="{{ old('check_out_time') }}">
                            @error('check_out_time')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Status -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="status">Status <span class="text-danger">*</span></label>
                            <select name="status" id="status" class="form-control @error('status') is-invalid @enderror" required>
                                <option value="">Select Status</option>
                                <option value="present" {{ old('status') == 'present' ? 'selected' : '' }}>Present</option>
                                <option value="late" {{ old('status') == 'late' ? 'selected' : '' }}>Late</option>
                                <option value="absent" {{ old('status') == 'absent' ? 'selected' : '' }}>Absent</option>
                                <option value="half_day" {{ old('status') == 'half_day' ? 'selected' : '' }}>Half Day</option>
                                <option value="overtime" {{ old('status') == 'overtime' ? 'selected' : '' }}>Overtime</option>
                            </select>
                            @error('status')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Device ID -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="device_id">Device ID</label>
                            <input type="text" name="device_id" id="device_id" 
                                   class="form-control @error('device_id') is-invalid @enderror" 
                                   value="{{ old('device_id') }}" placeholder="Enter device ID">
                            @error('device_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Check In Location -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_in_location">Check In Location</label>
                            <input type="text" name="check_in_location" id="check_in_location" 
                                   class="form-control @error('check_in_location') is-invalid @enderror" 
                                   value="{{ old('check_in_location') }}" placeholder="Enter check-in location">
                            @error('check_in_location')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <!-- Check Out Location -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="check_out_location">Check Out Location</label>
                            <input type="text" name="check_out_location" id="check_out_location" 
                                   class="form-control @error('check_out_location') is-invalid @enderror" 
                                   value="{{ old('check_out_location') }}" placeholder="Enter check-out location">
                            @error('check_out_location')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Notes -->
                    <div class="col-md-12">
                        <div class="form-group">
                            <label for="notes">Notes</label>
                            <textarea name="notes" id="notes" rows="3" 
                                      class="form-control @error('notes') is-invalid @enderror" 
                                      placeholder="Enter any additional notes">{{ old('notes') }}</textarea>
                            @error('notes')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save"></i> Create Attendance Record
                    </button>
                    <a href="{{ route('admin.attendances.index') }}" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Cancel
                    </a>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('script')
<script>
$(document).ready(function() {
    // Auto-populate check-in time with current time
    $('#check_in_time').on('focus', function() {
        if (!$(this).val()) {
            const now = new Date();
            const timeString = now.toTimeString().slice(0, 5);
            $(this).val(timeString);
        }
    });

    // Auto-populate check-out time with current time
    $('#check_out_time').on('focus', function() {
        if (!$(this).val()) {
            const now = new Date();
            const timeString = now.toTimeString().slice(0, 5);
            $(this).val(timeString);
        }
    });

    // Auto-populate device ID with a sample
    $('#device_id').on('focus', function() {
        if (!$(this).val()) {
            $(this).val('ADMIN_' + Date.now());
        }
    });
});
</script>
@endsection
