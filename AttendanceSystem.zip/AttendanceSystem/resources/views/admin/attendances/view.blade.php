@extends('admin.layout.app')
@section('title', 'View Attendance')
@section('content')
<div class="container-fluid">
    <!-- View Attendance Details -->
    <div class="card mb-4">
        <div class="card-header py-3 d-flex align-items-center justify-content-between">
            <h6 class="m-0 font-weight-bold text-primary">Attendance Details</h6>
            <div>
                <a href="{{ route('admin.attendances.edit', $attendance->id) }}" class="btn btn-warning text-white">
                    <i class="fas fa-edit"></i> Edit
                </a>
                <a href="{{ route('admin.attendances.index') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Back to List
                </a>
            </div>
        </div>
        <div class="card-body">
            <div class="row">
                <!-- Employee Information -->
                <div class="col-md-6">
                    <h5 class="mb-3 text-secondary border-bottom pb-2">Employee Information</h5>
                    <div class="form-group">
                        <label><strong>Employee Name</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->user->name }}</p>
                    </div>
                    <div class="form-group">
                        <label><strong>Email</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->user->email }}</p>
                    </div>
                    <div class="form-group">
                        <label><strong>Business Unit</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->employeeDetail->businessUnit->name ?? 'N/A' }}</p>
                    </div>
                    <div class="form-group">
                        <label><strong>Timezone</strong></label>
                        <p class="form-control-plaintext">
                            <span class="badge bg-info">{{ $attendance->getBusinessUnitTimezone() }}</span>
                        </p>
                    </div>
                    <div class="form-group">
                        <label><strong>Position</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->employeeDetail->position ?? 'N/A' }}</p>
                    </div>
                </div>

                <!-- Attendance Information -->
                <div class="col-md-6">
                    <h5 class="mb-3 text-secondary border-bottom pb-2">Attendance Information</h5>
                    <div class="form-group">
                        <label><strong>Attendance Date</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->attendance_date->format('d M, Y') }}</p>
                    </div>
                    <div class="form-group">
                        <label><strong>Status</strong></label>
                        <div class="mt-2">
                            <span class="badge {{ $attendance->getStatusBadgeClass() }} p-2">
                                {{ $attendance->getStatusLabel() }}
                            </span>
                        </div>
                    </div>
                    <div class="form-group">
                        <label><strong>Device ID</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->device_id ?? 'N/A' }}</p>
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <!-- Time Information -->
            <h5 class="mb-3 text-secondary border-bottom pb-2">Time Information</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Check In Time</strong></label>
                        <p class="form-control-plaintext">
                            @if($attendance->check_in_time)
                                <span class="text-success">{{ $attendance->getTimezoneAwareCheckInTime() }}</span>
                            @else
                                <span class="text-muted">Not checked in</span>
                            @endif
                        </p>
                    </div>
                    <div class="form-group">
                        <label><strong>Check Out Time</strong></label>
                        <p class="form-control-plaintext">
                            @if($attendance->check_out_time)
                                <span class="text-danger">{{ $attendance->getTimezoneAwareCheckOutTime() }}</span>
                            @else
                                <span class="text-muted">Not checked out</span>
                            @endif
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Scheduled Time</strong></label>
                        <p class="form-control-plaintext">
                            @if($attendance->scheduled_check_in && $attendance->scheduled_check_out)
                                {{ $attendance->getTimezoneAwareScheduledTimes() }}
                            @else
                                <span class="text-muted">Not set</span>
                            @endif
                        </p>
                    </div>
                    <div class="form-group">
                        <label><strong>Working Time</strong></label>
                        <p class="form-control-plaintext">
                            @if($attendance->total_working_minutes > 0)
                                <span class="text-info">{{ $attendance->getFormattedWorkingTime() }}</span>
                            @else
                                <span class="text-muted">N/A</span>
                            @endif
                        </p>
                    </div>
                </div>
            </div>

            <hr class="my-4">

            <!-- Late/Early Information -->
            <h5 class="mb-3 text-secondary border-bottom pb-2">Late/Early Information</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Late Arrival</strong></label>
                        <p class="form-control-plaintext">
                            @if($attendance->late_minutes > 0)
                                <span class="text-warning">
                                    <i class="fas fa-clock"></i> {{ $attendance->getFormattedLateTime() }}
                                </span>
                            @else
                                <span class="text-success">On Time</span>
                            @endif
                        </p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Early Departure</strong></label>
                        <p class="form-control-plaintext">
                            @if($attendance->early_departure_minutes > 0)
                                <span class="text-info">
                                    <i class="fas fa-clock"></i> {{ $attendance->getFormattedEarlyDepartureTime() }}
                                </span>
                            @else
                                <span class="text-success">On Time</span>
                            @endif
                        </p>
                    </div>
                </div>
            </div>

            <!-- Location Information -->
            @if($attendance->check_in_location || $attendance->check_out_location)
            <hr class="my-4">
            <h5 class="mb-3 text-secondary border-bottom pb-2">Location Information</h5>
            <div class="row">
                @if($attendance->check_in_location)
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Check In Location</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->check_in_location }}</p>
                    </div>
                </div>
                @endif
                @if($attendance->check_out_location)
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Check Out Location</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->check_out_location }}</p>
                    </div>
                </div>
                @endif
            </div>
            @endif

            <!-- Notes -->
            @if($attendance->notes)
            <hr class="my-4">
            <h5 class="mb-3 text-secondary border-bottom pb-2">Notes</h5>
            <div class="form-group">
                <p class="form-control-plaintext">{{ $attendance->notes }}</p>
            </div>
            @endif

            <!-- Additional Information -->
            <hr class="my-4">
            <h5 class="mb-3 text-secondary border-bottom pb-2">Additional Information</h5>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Created At</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->created_at->format('d M, Y h:i A') }}</p>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label><strong>Last Updated</strong></label>
                        <p class="form-control-plaintext">{{ $attendance->updated_at->format('d M, Y h:i A') }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
