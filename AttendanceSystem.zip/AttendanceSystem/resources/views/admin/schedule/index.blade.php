@extends('admin.layout.app')
@section('title', 'Business Unit')
@section('content')
    <div class="container-fluid">
        <!-- Create New Applicant -->
        <div class="card mb-4">
            <div class="card-header py-3 d-flex align-items-center justify-content-between">
                <h6 class="m-2 font-weight-bold text-primary">Business Unit</h6>
                <div class="crud-icons d-flex gap-3 ms-auto rounded p-2">
                    @can('users-create')
                        <div>
                            <button type="button" class="btn btn-primary text-white" title="Add" data-toggle="modal"
                                data-target="#addScheduleModal">
                                <i class="fas fa-plus"></i>
                            </button>
                        </div>
                    @endcan

                </div>
            </div>
        </div>
        <!-- Data view for applicants -->
        <div class="card shadow mb-4">
            <div class="card-body">
                <div class="table-responsive card-body">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Time In</th>
                                <th>Time Out</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data as $key => $unit)
                                <tr>
                                    <td>{{ ++$key }}</td>
                                    <td>{{ $unit->name }}</td>
                                    <td>{{ \Carbon\Carbon::parse($unit->time_in)->format('h:i A') }}</td>
                                    <td>{{ \Carbon\Carbon::parse($unit->time_out)->format('h:i A') }}</td>

                                    <td>
                                        <div
                                            class="crud-icons d-flex align-items-center justify-content-center gap-3  rounded p-2">
                                            <div>
                                                <a href="#" id="editButton{{ $unit->id }}"
                                                    data-toggle="modal"
                                                    data-target="#editScheduleModal"
                                                    data-id="{{ $unit->id }}"
                                                    data-name="{{ $unit->name }}"
                                                    data-time-in="{{ $unit->time_in }}"
                                                    data-time-out="{{ $unit->time_out }}"
                                                    class="btn btn-warning mx-3 text-white" title="Edit">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            </div>
                                            {{-- <div>
                                                <form action="{{ route('admin.business-unit.destroy', $unit->id) }}"
                                                    method="POST" style="display: inline;"
                                                    onsubmit="return confirm('Are you sure you want to delete this user?');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger text-white" title="Delete">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                            </div> --}}
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    @include('admin.schedule.create')
    @include('admin.schedule.edit')

@endsection
@section('js')
<script>
$(document).ready(function() {
    // When any edit button is clicked
    $('a[id^="editButton"]').on('click', function() {
        // Get the data attributes from the clicked button
        var id = $(this).data('id');
        var name = $(this).data('name');
        var timeIn = $(this).data('time-in');
        var timeOut = $(this).data('time-out');

        // Populate the modal fields with the values
        $('#editScheduleModal').find('#name').val(name);
        $('#editScheduleModal').find('#time_in').val(timeIn.substring(0, 5));
        $('#editScheduleModal').find('#time_out').val(timeOut.substring(0, 5));

        $('#editScheduleForm').attr('action', '/admin/schedules/' + id);
    });
});
</script>



@endsection
